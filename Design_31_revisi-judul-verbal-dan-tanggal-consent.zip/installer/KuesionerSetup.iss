; Bangun aplikasi terlebih dahulu dengan publish Release win-x64.
; Paket final memasang aplikasi pada C:\Program Files\Kuesioner dan menyertakan Video\Video.mp4.
; Compiler: Inno Setup 6+

#define MyAppName "Kuesioner Skripsi"
#define MyAppVersion "1.0.0"
#define MyAppExeName "KuesionerSkripsi.App.exe"

[Setup]
AppId={{BBE3E515-116B-4F2E-99ED-889C2D70BBD4}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName={autopf}\Kuesioner
DefaultGroupName={#MyAppName}
OutputBaseFilename=KuesionerSetup
SetupIconFile=..\src\KuesionerSkripsi.App\Resources\Images\KuesionerSkripsi.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin

[Files]
Source: "..\publish\win-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Dirs]
Name: "{app}\Video"
Name: "D:\Kuesioner"
Name: "D:\Kuesioner\Database"
Name: "D:\Kuesioner\Database\Arsip"
Name: "D:\Kuesioner\Video Animasi Edukasi\Hasil PDF"
Name: "D:\Kuesioner\Video Animasi Edukasi\Hasil Exel"
Name: "D:\Kuesioner\Video Animasi Edukasi\Hasil Exel\Arsip"
Name: "D:\Kuesioner\Edukasi Verbal\Hasil PDF"
Name: "D:\Kuesioner\Edukasi Verbal\Hasil Exel"
Name: "D:\Kuesioner\Edukasi Verbal\Hasil Exel\Arsip"

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Buat pintasan di desktop"; GroupDescription: "Pilihan tambahan:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Buka aplikasi setelah instalasi"; Flags: nowait postinstall skipifsilent
