# Changelog

## Design_30 - Tanggal Bahasa Indonesia dan Revisi Pertanyaan

- Mengubah seluruh tampilan tanggal responden menjadi format Bahasa Indonesia dengan nama hari di depan dan nama bulan penuh, contohnya `Selasa, 22 Juni 2026`.
- Menerapkan format tersebut pada halaman Data Responden, Informed Consent, PDF informed consent, PDF kuesioner, serta tampilan tanggal di rekap Excel.
- Menjaga nilai tanggal pada Excel sebagai tipe tanggal agar tetap siap diolah melalui SPSS.
- Mengubah pertanyaan ke-5 MDAS-DEP menjadi: `Jika gigi Anda akan dicabut melalui prosedur ekstraksi gigi, bagaimana perasaan Anda?`
- Perubahan pertanyaan diterapkan pada layar kuesioner dan PDF hasil pre-test maupun post-test.
