using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public abstract class PageViewModel : ObservableObject
{
    public abstract string Title { get; }
    public abstract string Subtitle { get; }
}
