using System.Globalization;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using KuesionerSkripsi.Core.Models;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

/// <summary>
/// Tahap 02. Menampilkan informed consent dengan data yang sudah disetujui pada form data responden.
/// Halaman ini tidak membuat tanda tangan baru. Tanda tangan responden berasal dari tahap data responden.
/// </summary>
public sealed class InformedConsentViewModel : PageViewModel
{
    private readonly ResearchSession _session;

    public InformedConsentViewModel(ResearchSession session, Action backToRespondent, Action continueToPreTest)
    {
        _session = session;
        BackCommand = new RelayCommand(backToRespondent);
        ContinueCommand = new RelayCommand(continueToPreTest, () => Respondent.HasSignature);
        RespondentSignatureImage = CreateImageSource(Respondent.SignaturePng);
    }

    public override string Title => "Informed Consent";
    public override string Subtitle => "Tinjau persetujuan sebelum memilih jenis kuesioner.";

    public Respondent Respondent => _session.Respondent;

    public string QuestionnaireDateDisplay => Respondent.QuestionnaireDate.ToString("dddd, dd MMMM yyyy", new CultureInfo("id-ID"));

    public string ConsentLocationAndDate => $"Purbalingga, {QuestionnaireDateDisplay}";

    public ImageSource? RespondentSignatureImage { get; }

    public RelayCommand BackCommand { get; }
    public RelayCommand ContinueCommand { get; }

    private static ImageSource? CreateImageSource(byte[]? pngData)
    {
        if (pngData is not { Length: > 0 })
        {
            return null;
        }

        try
        {
            using var stream = new MemoryStream(pngData, writable: false);
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = stream;
            image.EndInit();
            image.Freeze();
            return image;
        }
        catch
        {
            // Halaman tetap dapat dibuka. Validasi tanda tangan dilakukan pada tahap data responden.
            return null;
        }
    }
}
