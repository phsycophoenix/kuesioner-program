using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class VerbalEducationViewModel : PageViewModel
{
    private readonly Action _continueToPostQuestionnaire;
    private readonly Action _backToPreQuestionnaire;

    public VerbalEducationViewModel(Action continueToPostQuestionnaire, Action backToPreQuestionnaire)
    {
        _continueToPostQuestionnaire = continueToPostQuestionnaire;
        _backToPreQuestionnaire = backToPreQuestionnaire;
        ContinueCommand = new RelayCommand(ContinueToPostQuestionnaire);
        BackCommand = new RelayCommand(_backToPreQuestionnaire);
    }

    public override string Title => "Edukasi Verbal Pra Tindakan";

    public override string Subtitle => "Petugas atau peneliti memberikan edukasi verbal sesuai materi dan prosedur penelitian yang telah disetujui.";

    public RelayCommand ContinueCommand { get; }
    public RelayCommand BackCommand { get; }

    private void ContinueToPostQuestionnaire()
    {
        _continueToPostQuestionnaire();
    }
}
