using System.Collections.ObjectModel;
using System.ComponentModel;
using KuesionerSkripsi.Core.Models;
using KuesionerSkripsi.Core.Services;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class QuestionnaireViewModel : PageViewModel
{
    private readonly ResearchSession _session;
    private readonly AnxietyScoringService _scoringService;
    private readonly bool _isPreIntervention;
    private readonly Action _completed;
    private string _validationMessage = string.Empty;

    public QuestionnaireViewModel(ResearchSession session, AnxietyScoringService scoringService, bool isPreIntervention, Action completed, Action back)
    {
        _session = session;
        _scoringService = scoringService;
        _isPreIntervention = isPreIntervention;
        _completed = completed;
        CompleteCommand = new RelayCommand(Complete);
        BackCommand = new RelayCommand(back);

        Questions = new ObservableCollection<QuestionItemViewModel>(CreateQuestions(GetInitialScores()));
        foreach (var question in Questions)
        {
            question.PropertyChanged += OnQuestionChanged;
        }
    }

    public override string Title => _session.InterventionType switch
    {
        InterventionTypes.VideoAnimationEducation => _isPreIntervention
            ? "Kuesioner Pra Intervensi Video Animasi Sebagai Media Edukasi Pada Tingkat Kecemasan Pasien Ekstraksi Gigi"
            : "Kuesioner Post Intervensi Video Animasi Sebagai Media Edukasi Pada Tingkat Kecemasan Pasien Ekstraksi Gigi",
        InterventionTypes.VerbalEducation => _isPreIntervention
            ? "Kuesioner Pra Intervensi Edukasi Verbal Sebagai Media Edukasi Pada Tingkat Kecemasan Pasien Ekstraksi Gigi"
            : "Kuesioner Post Intervensi Edukasi Verbal Sebagai Media Edukasi Pada Tingkat Kecemasan Pasien Ekstraksi Gigi",
        _ => "Kuesioner Tingkat Kecemasan Pasien Ekstraksi Gigi"
    };

    public override string Subtitle => string.Empty;
    public bool IsPreIntervention => _isPreIntervention;
    public string PhaseLabel => _session.InterventionType switch
    {
        InterventionTypes.VideoAnimationEducation => _isPreIntervention ? "PRA INTERVENSI VIDEO" : "POST INTERVENSI VIDEO",
        InterventionTypes.VerbalEducation => _isPreIntervention ? "PRA EDUKASI VERBAL" : "POST EDUKASI VERBAL",
        _ => _isPreIntervention ? "PRA INTERVENSI" : "POST INTERVENSI"
    };

    public string ContinueLabel => _isPreIntervention
        ? _session.InterventionType == InterventionTypes.VerbalEducation
            ? "Simpan dan Lanjut ke Edukasi Verbal"
            : "Simpan dan Lanjut ke Video Edukasi"
        : "Simpan dan Lihat Ringkasan";

    public string BackLabel => IsPreIntervention ? "Kembali ke Pilih Kuesioner" : "Kembali ke Intervensi";

    public string RespondentSummary => $"{_session.Respondent.FullName} • {_session.Respondent.AgeDisplay} • {_session.Respondent.Gender}";

    public ObservableCollection<QuestionItemViewModel> Questions { get; }
    public ObservableCollection<AnswerChoice> Choices { get; } = new([
        new(1, "Tidak cemas"),
        new(2, "Sedikit cemas"),
        new(3, "Cukup cemas"),
        new(4, "Cemas"),
        new(5, "Sangat cemas")
    ]);

    public string ValidationMessage
    {
        get => _validationMessage;
        private set => SetProperty(ref _validationMessage, value);
    }

    public RelayCommand CompleteCommand { get; }
    public RelayCommand BackCommand { get; }

    private IReadOnlyList<int> GetInitialScores()
    {
        var previousAnswers = _isPreIntervention
            ? _session.PreAssessment?.Answers
            : _session.PostAssessment?.Answers;

        if (previousAnswers is { Count: 5 } && previousAnswers.All(score => score is >= 1 and <= 5))
        {
            return previousAnswers;
        }

        return Enumerable.Repeat(GetDefaultScore(), 5).ToArray();
    }

    private int GetDefaultScore()
    {
        if (_isPreIntervention)
        {
            return 5;
        }

        // Default lama video tetap "Tidak cemas". Default verbal tetap "Cukup cemas".
        return _session.InterventionType == InterventionTypes.VerbalEducation ? 3 : 1;
    }

    private void Complete()
    {
        if (Questions.Any(question => question.SelectedScore is null))
        {
            ValidationMessage = "Setiap pertanyaan harus dijawab sebelum melanjutkan.";
            return;
        }

        var assessment = _scoringService.Calculate(Questions.Select(question => question.SelectedScore!.Value));
        if (_isPreIntervention)
        {
            _session.PreAssessment = assessment;
        }
        else
        {
            _session.PostAssessment = assessment;
        }

        ValidationMessage = string.Empty;
        _completed();
    }

    private void OnQuestionChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(QuestionItemViewModel.SelectedScore))
        {
            ValidationMessage = string.Empty;
        }
    }

    private static IEnumerable<QuestionItemViewModel> CreateQuestions(IReadOnlyList<int> initialScores)
    {
        yield return new QuestionItemViewModel(1, "Jika Anda diberitahu bahwa salah satu gigi Anda harus dicabut, bagaimana perasaan Anda?", initialScores[0]);
        yield return new QuestionItemViewModel(2, "Jika besok Anda akan menjalani tindakan ekstraksi gigi, bagaimana perasaan Anda?", initialScores[1]);
        yield return new QuestionItemViewModel(3, "Jika Anda sedang menunggu di ruang tunggu untuk tindakan ekstraksi gigi, bagaimana perasaan Anda?", initialScores[2]);
        yield return new QuestionItemViewModel(4, "Jika Anda akan mendapatkan suntikan anestesi lokal pada gusi, bagaimana perasaan Anda?", initialScores[3]);
        yield return new QuestionItemViewModel(5, "Jika gigi Anda akan dicabut melalui prosedur ekstraksi gigi, bagaimana perasaan Anda?", initialScores[4]);
    }
}
