using KuesionerSkripsi.Core.Models;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

/// <summary>
/// Tahap setelah informed consent. Responden memilih tepat satu jalur kuesioner.
/// </summary>
public sealed class InterventionSelectionViewModel : PageViewModel
{
    private readonly ResearchSession _session;
    private readonly Action _continueToPreTest;

    public InterventionSelectionViewModel(ResearchSession session, Action backToConsent, Action continueToPreTest)
    {
        _session = session;
        _continueToPreTest = continueToPreTest;
        BackCommand = new RelayCommand(backToConsent);
        SelectVideoCommand = new RelayCommand(() => Select(InterventionTypes.VideoAnimationEducation));
        SelectVerbalCommand = new RelayCommand(() => Select(InterventionTypes.VerbalEducation));
    }

    public override string Title => "Pilih Jenis Kuesioner";
    public override string Subtitle => "Pilih satu jenis edukasi sebelum memulai pengisian kuesioner pre-test.";

    public RelayCommand BackCommand { get; }
    public RelayCommand SelectVideoCommand { get; }
    public RelayCommand SelectVerbalCommand { get; }

    private void Select(string interventionType)
    {
        _session.InterventionType = interventionType;
        _continueToPreTest();
    }
}
