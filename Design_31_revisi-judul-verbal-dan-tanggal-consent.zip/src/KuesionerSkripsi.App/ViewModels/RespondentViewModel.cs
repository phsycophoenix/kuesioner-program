using System.Collections.ObjectModel;
using System.ComponentModel;
using KuesionerSkripsi.Core.Models;
using KuesionerSkripsi.Core.Services;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class RespondentViewModel : PageViewModel
{
    private readonly ResearchSession _session;
    private readonly EligibilityService _eligibilityService;
    private readonly Action _eligible;
    private readonly Action _ineligible;
    private string _validationMessage = string.Empty;
    private string _eligibilityMessage = string.Empty;
    private string _eligibilityTone = "Info";
    private string _eligibilityIcon = "i";
    private string _submissionGuidance = "Isi nomor rekam medis terlebih dahulu untuk membuka kolom nama lengkap.";

    public RespondentViewModel(ResearchSession session, EligibilityService eligibilityService, Action eligible, Action ineligible, Action backToStart)
    {
        _session = session;
        _eligibilityService = eligibilityService;
        _eligible = eligible;
        _ineligible = ineligible;

        SubmitCommand = new RelayCommand(Submit);
        BackCommand = new RelayCommand(backToStart);
        ShowIneligibleCommand = new RelayCommand(ShowIneligible, () => IsAgeOutOfRange || IsConsentDeclined);

        Respondent.PropertyChanged += RespondentOnPropertyChanged;
        RefreshEligibilityPreview();
    }

    public override string Title => "Data Responden";
    public override string Subtitle => "Lengkapi data responden sebelum melanjutkan ke tahapan penelitian.";

    public Respondent Respondent => _session.Respondent;

    public ObservableCollection<string> Genders { get; } = new(["Laki-laki", "Perempuan"]);
    public ObservableCollection<string> Educations { get; } = new([
        "Tidak Sekolah", "Tidak Tamat SD", "SD/MI/Sederajat", "SMP/MTs/Sederajat",
        "SMA/MA/SMK/Sederajat", "D1/D2/D3", "S1", "S2", "S3", "Lainnya"
    ]);
    public ObservableCollection<string> ExtractionExperiences { get; } = new(["Pernah", "Tidak Pernah"]);
    public ObservableCollection<string> ConsentChoices { get; } = new([
        EligibilityService.ConsentAccepted,
        EligibilityService.ConsentDeclined
    ]);

    public string ValidationMessage
    {
        get => _validationMessage;
        private set => SetProperty(ref _validationMessage, value);
    }

    public string EligibilityMessage
    {
        get => _eligibilityMessage;
        private set => SetProperty(ref _eligibilityMessage, value);
    }

    /// <summary>Info, Warning, atau Success. Dipakai XAML untuk warna kartu kelayakan.</summary>
    public string EligibilityTone
    {
        get => _eligibilityTone;
        private set => SetProperty(ref _eligibilityTone, value);
    }

    public string EligibilityIcon
    {
        get => _eligibilityIcon;
        private set => SetProperty(ref _eligibilityIcon, value);
    }

    /// <summary>True bila responden secara eksplisit memilih tidak bersedia.</summary>
    public bool IsConsentDeclined => Respondent.ConsentChoice == EligibilityService.ConsentDeclined;

    /// <summary>False hanya bila responden secara eksplisit memilih tidak bersedia.</summary>
    public bool IsRespondentFormInputEnabled => !IsConsentDeclined;

    /// <summary>
    /// Kolom setelah tanggal lahir baru dibuka ketika responden bersedia dan usianya berada pada rentang 17–59 tahun.
    /// </summary>
    public bool ArePostBirthDateInputsEnabled =>
        IsRespondentFormInputEnabled &&
        Respondent.BirthDate is not null &&
        Respondent.BirthDate.Value.Date <= Respondent.QuestionnaireDate.Date &&
        Respondent.AgeInYears is >= EligibilityService.MinimumAge and <= EligibilityService.MaximumAge;

    /// <summary>Nama lengkap terbuka setelah nomor rekam medis diisi.</summary>
    public bool IsFullNameInputEnabled =>
        IsRespondentFormInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.MedicalRecordNumber);

    /// <summary>Tempat lahir terbuka setelah nama lengkap diisi.</summary>
    public bool IsBirthPlaceInputEnabled =>
        IsFullNameInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.FullName);

    /// <summary>Tanggal lahir terbuka setelah tempat lahir diisi.</summary>
    public bool IsBirthDateInputEnabled =>
        IsBirthPlaceInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.BirthPlace);

    /// <summary>Jenis kelamin terbuka setelah tanggal lahir valid dan usia memenuhi kriteria.</summary>
    public bool IsGenderInputEnabled =>
        IsBirthDateInputEnabled &&
        ArePostBirthDateInputsEnabled;

    /// <summary>Pengalaman pencabutan gigi terbuka setelah jenis kelamin dipilih.</summary>
    public bool IsExtractionExperienceInputEnabled =>
        IsGenderInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.Gender);

    /// <summary>Pendidikan terbuka setelah pengalaman pencabutan gigi tersedia.</summary>
    public bool IsEducationInputEnabled =>
        IsExtractionExperienceInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.ExtractionExperience);

    /// <summary>Penjelasan pendidikan lainnya terbuka ketika pilihan pendidikan adalah Lainnya.</summary>
    public bool IsOtherEducationInputEnabled =>
        IsEducationInputEnabled &&
        Respondent.Education == "Lainnya";

    /// <summary>Alamat terbuka setelah pendidikan, dan bila perlu penjelasan pendidikan lainnya, diisi.</summary>
    public bool IsAddressInputEnabled =>
        IsEducationInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.Education) &&
        (Respondent.Education != "Lainnya" || !string.IsNullOrWhiteSpace(Respondent.OtherEducation));

    /// <summary>Tanda tangan terbuka setelah alamat lengkap diisi.</summary>
    public bool IsSignatureInputEnabled =>
        IsAddressInputEnabled &&
        !string.IsNullOrWhiteSpace(Respondent.Address);

    /// <summary>True saat tanggal lahir terisi tetapi usia tidak memenuhi 17–59 tahun, termasuk tanggal lahir di masa depan.</summary>
    public bool IsAgeOutOfRange =>
        Respondent.BirthDate is not null &&
        (Respondent.BirthDate.Value.Date > Respondent.QuestionnaireDate.Date ||
         Respondent.AgeInYears is < EligibilityService.MinimumAge or > EligibilityService.MaximumAge);

    public string SubmissionGuidance
    {
        get => _submissionGuidance;
        private set => SetProperty(ref _submissionGuidance, value);
    }

    public RelayCommand SubmitCommand { get; }
    public RelayCommand BackCommand { get; }
    public RelayCommand ShowIneligibleCommand { get; }

    private void ShowIneligible()
    {
        if (!IsAgeOutOfRange && !IsConsentDeclined)
        {
            return;
        }

        ValidationMessage = string.Empty;
        _ineligible();
    }

    private void Submit()
    {
        // Bila responden tidak bersedia, semua kolom lain terkunci dan aplikasi langsung membuka halaman Terima Kasih.
        if (Respondent.ConsentChoice == EligibilityService.ConsentDeclined)
        {
            ValidationMessage = string.Empty;
            _ineligible();
            return;
        }

        // Bila tanggal lahir sudah dipilih tetapi usia berada di luar kriteria, tidak perlu melengkapi kolom lain.
        if (IsAgeOutOfRange)
        {
            ValidationMessage = string.Empty;
            _ineligible();
            return;
        }

        var missingFields = GetMissingCommonFields();
        if (missingFields.Count > 0)
        {
            ValidationMessage = "Lengkapi: " + string.Join(", ", missingFields) + ".";
            return;
        }

        if (!_eligibilityService.IsEligible(Respondent))
        {
            ValidationMessage = string.Empty;
            _ineligible();
            return;
        }

        if (!Respondent.HasSignature)
        {
            ValidationMessage = "Tanda tangan responden wajib diisi untuk melanjutkan.";
            return;
        }

        ValidationMessage = string.Empty;
        _eligible();
    }

    private List<string> GetMissingCommonFields()
    {
        var missingFields = new List<string>();
        if (string.IsNullOrWhiteSpace(Respondent.MedicalRecordNumber)) missingFields.Add("Nomor rekam medis");
        if (string.IsNullOrWhiteSpace(Respondent.FullName)) missingFields.Add("Nama lengkap");
        if (string.IsNullOrWhiteSpace(Respondent.BirthPlace)) missingFields.Add("Tempat lahir");
        if (Respondent.BirthDate is null || Respondent.BirthDate.Value.Date > Respondent.QuestionnaireDate.Date) missingFields.Add("Tanggal lahir");
        if (string.IsNullOrWhiteSpace(Respondent.Gender)) missingFields.Add("Jenis kelamin");
        if (string.IsNullOrWhiteSpace(Respondent.Education)) missingFields.Add("Pendidikan");
        if (Respondent.Education == "Lainnya" && string.IsNullOrWhiteSpace(Respondent.OtherEducation)) missingFields.Add("Penjelasan pendidikan lainnya");
        if (string.IsNullOrWhiteSpace(Respondent.Address)) missingFields.Add("Alamat lengkap");
        if (string.IsNullOrWhiteSpace(Respondent.ExtractionExperience)) missingFields.Add("Pengalaman pencabutan gigi");
        if (string.IsNullOrWhiteSpace(Respondent.ConsentChoice)) missingFields.Add("pilihan persetujuan");
        return missingFields;
    }

    private void RespondentOnPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (!string.IsNullOrEmpty(ValidationMessage))
        {
            ValidationMessage = string.Empty;
        }

        OnPropertyChanged(nameof(IsConsentDeclined));
        OnPropertyChanged(nameof(IsRespondentFormInputEnabled));
        OnPropertyChanged(nameof(ArePostBirthDateInputsEnabled));
        OnPropertyChanged(nameof(IsFullNameInputEnabled));
        OnPropertyChanged(nameof(IsBirthPlaceInputEnabled));
        OnPropertyChanged(nameof(IsBirthDateInputEnabled));
        OnPropertyChanged(nameof(IsGenderInputEnabled));
        OnPropertyChanged(nameof(IsExtractionExperienceInputEnabled));
        OnPropertyChanged(nameof(IsEducationInputEnabled));
        OnPropertyChanged(nameof(IsOtherEducationInputEnabled));
        OnPropertyChanged(nameof(IsAddressInputEnabled));
        OnPropertyChanged(nameof(IsSignatureInputEnabled));
        OnPropertyChanged(nameof(IsAgeOutOfRange));
        ShowIneligibleCommand.RaiseCanExecuteChanged();

        RefreshEligibilityPreview();
    }

    private void RefreshEligibilityPreview()
    {
        if (Respondent.ConsentChoice == EligibilityService.ConsentDeclined)
        {
            SubmissionGuidance = "Responden memilih tidak bersedia. Klik Simpan dan Lanjut untuk membuka halaman Terima Kasih.";
            SetEligibilityPreview(_eligibilityService.GetIneligibilityReason(Respondent), "Warning", "!");
            return;
        }

        if (string.IsNullOrWhiteSpace(Respondent.MedicalRecordNumber))
        {
            SubmissionGuidance = "Isi nomor rekam medis terlebih dahulu untuk membuka kolom nama lengkap.";
            SetEligibilityPreview("Nomor rekam medis belum diisi.", "Info", "i");
            return;
        }

        if (string.IsNullOrWhiteSpace(Respondent.FullName))
        {
            SubmissionGuidance = "Isi nama lengkap untuk membuka kolom tempat lahir.";
            SetEligibilityPreview("Nama lengkap belum diisi.", "Info", "i");
            return;
        }

        if (string.IsNullOrWhiteSpace(Respondent.BirthPlace))
        {
            SubmissionGuidance = "Isi tempat lahir untuk membuka pilihan tanggal lahir.";
            SetEligibilityPreview("Tempat lahir belum diisi.", "Info", "i");
            return;
        }

        if (Respondent.BirthDate is null)
        {
            SubmissionGuidance = "Pilih tanggal lahir untuk membuka pilihan jenis kelamin.";
            SetEligibilityPreview(
                "Tanggal lahir belum diisi. Sistem akan memeriksa usia secara otomatis setelah tanggal lahir dipilih.",
                "Info",
                "i");
            return;
        }

        if (IsAgeOutOfRange)
        {
            SubmissionGuidance = "Umur responden tidak memenuhi persyaratan. Klik kotak merah pada bagian Umur untuk membuka halaman Terima Kasih.";
            SetEligibilityPreview("Usia responden harus berada pada rentang 17–59 tahun.", "Warning", "!");
            return;
        }

        if (Respondent.ConsentChoice == EligibilityService.ConsentAccepted)
        {
            if (string.IsNullOrWhiteSpace(Respondent.Gender))
            {
                SubmissionGuidance = "Pilih jenis kelamin untuk membuka pilihan pengalaman pencabutan gigi sebelumnya.";
                SetEligibilityPreview("Usia memenuhi kriteria. Pilih jenis kelamin untuk melanjutkan pengisian data.", "Success", "✓");
                return;
            }

            if (string.IsNullOrWhiteSpace(Respondent.ExtractionExperience))
            {
                SubmissionGuidance = "Pilih pengalaman pencabutan gigi sebelumnya untuk membuka pilihan pendidikan.";
                SetEligibilityPreview("Pilih pengalaman pencabutan gigi sebelumnya untuk melanjutkan.", "Success", "✓");
                return;
            }

            if (string.IsNullOrWhiteSpace(Respondent.Education))
            {
                SubmissionGuidance = "Pilih pendidikan terakhir untuk membuka kolom alamat lengkap.";
                SetEligibilityPreview("Pilih pendidikan terakhir untuk melanjutkan.", "Success", "✓");
                return;
            }

            if (Respondent.Education == "Lainnya" && string.IsNullOrWhiteSpace(Respondent.OtherEducation))
            {
                SubmissionGuidance = "Jelaskan pendidikan lainnya untuk membuka kolom alamat lengkap.";
                SetEligibilityPreview("Penjelasan pendidikan lainnya belum diisi.", "Success", "✓");
                return;
            }

            if (string.IsNullOrWhiteSpace(Respondent.Address))
            {
                SubmissionGuidance = "Isi alamat lengkap untuk membuka area tanda tangan responden.";
                SetEligibilityPreview("Alamat lengkap belum diisi.", "Success", "✓");
                return;
            }

            SubmissionGuidance = Respondent.HasSignature
                ? "Data memenuhi kriteria awal dan tanda tangan sudah diterima. Klik Simpan dan Lanjut untuk membuka Informed Consent."
                : "Alamat lengkap sudah diisi. Tanda tangan responden telah dibuka dan wajib diisi untuk melanjutkan.";

            var signatureNote = Respondent.HasSignature
                ? "Data memenuhi kriteria awal dan tanda tangan sudah diterima."
                : "Alamat lengkap sudah diisi. Area tanda tangan responden telah dibuka.";
            SetEligibilityPreview(signatureNote, "Success", "✓");
            return;
        }

        SubmissionGuidance = "Pilih kesediaan responden untuk melanjutkan.";
        SetEligibilityPreview("Pilih kesediaan responden untuk melanjutkan.", "Info", "i");
    }

    private void SetEligibilityPreview(string message, string tone, string icon)
    {
        EligibilityMessage = message;
        EligibilityTone = tone;
        EligibilityIcon = icon;
    }
}
