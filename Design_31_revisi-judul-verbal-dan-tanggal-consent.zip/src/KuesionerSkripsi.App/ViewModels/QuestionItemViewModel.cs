using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class QuestionItemViewModel : ObservableObject
{
    // Nilai awal diberikan oleh halaman kuesioner: pre-test = 5 (Sangat cemas),
    // post-test = 1 (Tidak cemas). Responden tetap dapat mengubah jawaban.
    private int? _selectedScore;

    public QuestionItemViewModel(int number, string question, int defaultScore = 5)
    {
        if (defaultScore is < 1 or > 5)
        {
            throw new ArgumentOutOfRangeException(nameof(defaultScore));
        }

        Number = number;
        Question = question;
        _selectedScore = defaultScore;
    }

    public int Number { get; }
    public string Question { get; }
    public string RadioGroupName => $"Question_{Number}";

    public int? SelectedScore
    {
        get => _selectedScore;
        set
        {
            if (!SetProperty(ref _selectedScore, value))
            {
                return;
            }

            OnPropertyChanged(nameof(IsScore1));
            OnPropertyChanged(nameof(IsScore2));
            OnPropertyChanged(nameof(IsScore3));
            OnPropertyChanged(nameof(IsScore4));
            OnPropertyChanged(nameof(IsScore5));
        }
    }

    public bool IsScore1
    {
        get => SelectedScore == 1;
        set { if (value) SelectedScore = 1; }
    }

    public bool IsScore2
    {
        get => SelectedScore == 2;
        set { if (value) SelectedScore = 2; }
    }

    public bool IsScore3
    {
        get => SelectedScore == 3;
        set { if (value) SelectedScore = 3; }
    }

    public bool IsScore4
    {
        get => SelectedScore == 4;
        set { if (value) SelectedScore = 4; }
    }

    public bool IsScore5
    {
        get => SelectedScore == 5;
        set { if (value) SelectedScore = 5; }
    }
}
