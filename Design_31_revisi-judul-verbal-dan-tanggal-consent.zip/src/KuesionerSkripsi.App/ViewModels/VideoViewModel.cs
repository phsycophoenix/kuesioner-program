using System;
using System.IO;
using KuesionerSkripsi.Core.Services;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class VideoViewModel : PageViewModel
{
    private readonly Action _continueToPost;
    private readonly Action _backToPre;
    private Uri? _videoUri;
    private string _videoPath = string.Empty;
    private string _videoStatus = string.Empty;
    private bool _hasVideoSource;
    private bool _hasVideoError;
    private bool _isVideoCompleted;

    public VideoViewModel(Action continueToPost, Action backToPre)
    {
        _continueToPost = continueToPost;
        _backToPre = backToPre;
        ContinueCommand = new RelayCommand(_continueToPost, () => IsVideoCompleted && !HasVideoError);
        BackCommand = new RelayCommand(_backToPre);

        if (VideoPathService.TryResolveBundledVideo(out var bundledVideoPath))
        {
            SetVideoSource(bundledVideoPath, isReplacementVideo: false);
        }
        else
        {
            SetMissingVideoState();
        }
    }

    public override string Title => "Intervensi Video Animasi";
    public override string Subtitle => "Saksikan video edukasi sampai selesai sebelum melanjutkan ke kuesioner post intervensi.";

    public Uri? VideoUri
    {
        get => _videoUri;
        private set => SetProperty(ref _videoUri, value);
    }

    public string VideoPath
    {
        get => _videoPath;
        private set => SetProperty(ref _videoPath, value);
    }

    public string VideoStatus
    {
        get => _videoStatus;
        private set => SetProperty(ref _videoStatus, value);
    }

    public bool HasVideoSource
    {
        get => _hasVideoSource;
        private set => SetProperty(ref _hasVideoSource, value);
    }

    public bool HasVideoError
    {
        get => _hasVideoError;
        private set => SetProperty(ref _hasVideoError, value);
    }

    public bool IsVideoCompleted
    {
        get => _isVideoCompleted;
        private set
        {
            if (SetProperty(ref _isVideoCompleted, value))
            {
                ContinueCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public RelayCommand ContinueCommand { get; }
    public RelayCommand BackCommand { get; }

    public void SetReplacementVideo(string replacementVideoPath)
    {
        SetVideoSource(replacementVideoPath, isReplacementVideo: true);
    }

    public void NotifyMediaOpened()
    {
        if (!HasVideoSource)
        {
            return;
        }

        HasVideoError = false;
        IsVideoCompleted = false;
        VideoStatus = "Video sedang diputar. Mohon tunggu sampai video selesai.";
        ContinueCommand.RaiseCanExecuteChanged();
    }

    public void NotifyReplayStarted()
    {
        if (!HasVideoSource)
        {
            return;
        }

        HasVideoError = false;
        IsVideoCompleted = false;
        VideoStatus = "Video diputar ulang. Mohon tunggu sampai video selesai.";
        ContinueCommand.RaiseCanExecuteChanged();
    }

    public void NotifyMediaEndedAndContinue()
    {
        if (!HasVideoSource || HasVideoError)
        {
            return;
        }

        IsVideoCompleted = true;
        VideoStatus = "Video selesai diputar. Membuka kuesioner post intervensi.";
        ContinueCommand.RaiseCanExecuteChanged();
        _continueToPost();
    }

    public void NotifyMediaFailed(string? errorMessage)
    {
        HasVideoError = true;
        IsVideoCompleted = false;
        VideoStatus = "Video tidak dapat diputar. Pilih file Video.mp4 lain atau periksa kembali file video instalasi.";
        ContinueCommand.RaiseCanExecuteChanged();
    }

    private void SetVideoSource(string sourcePath, bool isReplacementVideo)
    {
        if (!File.Exists(sourcePath) || new FileInfo(sourcePath).Length == 0)
        {
            SetMissingVideoState();
            return;
        }

        VideoPath = sourcePath;
        VideoUri = new Uri(sourcePath, UriKind.Absolute);
        HasVideoSource = true;
        HasVideoError = false;
        IsVideoCompleted = false;
        VideoStatus = isReplacementVideo
            ? "Video pengganti dipilih. Video akan diputar otomatis."
            : "Video edukasi ditemukan. Video akan diputar otomatis.";
        ContinueCommand.RaiseCanExecuteChanged();
    }

    private void SetMissingVideoState()
    {
        VideoPath = string.Empty;
        VideoUri = null;
        HasVideoSource = false;
        HasVideoError = true;
        IsVideoCompleted = false;
        VideoStatus = "Video tidak ditemukan di C:\\Program Files\\Kuesioner\\Video\\Video.mp4. Pilih file video pengganti untuk melanjutkan.";
        ContinueCommand.RaiseCanExecuteChanged();
    }
}
