using System;
using System.Diagnostics;
using System.IO;
using KuesionerSkripsi.Core.Models;
using KuesionerSkripsi.Core.Services;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class ResultViewModel : PageViewModel
{
    private readonly PdfExportService _pdfExportService;
    private readonly SqliteSessionRepository _sessionRepository;
    private readonly ExcelRecapService _excelRecapService;
    private PdfExportResult? _exportResult;
    private ExcelRecapResult? _excelRecapResult;
    private string _exportStatus = "PDF belum dibuat. Klik Buat 3 PDF untuk menyimpan hasil responden.";
    private string _excelRecapStatus = "Rekap Excel gabungan sedang disiapkan dari database lokal.";
    private bool _isExporting;
    private bool _isUpdatingExcelRecap;

    public ResultViewModel(
        ResearchSession session,
        PdfExportService pdfExportService,
        SqliteSessionRepository sessionRepository,
        ExcelRecapService excelRecapService,
        Action restart,
        Action backToPostQuestionnaire)
    {
        Session = session;
        _pdfExportService = pdfExportService;
        _sessionRepository = sessionRepository;
        _excelRecapService = excelRecapService;

        RestartCommand = new RelayCommand(restart);
        BackCommand = new RelayCommand(backToPostQuestionnaire);
        GeneratePdfsCommand = new RelayCommand(GeneratePdfs, () => !IsExporting);
        OpenOutputFolderCommand = new RelayCommand(OpenOutputFolder);
        OpenInformedConsentCommand = new RelayCommand(() => OpenFile(ExportResult?.InformedConsentPath), () => ExportResult is not null);
        OpenPreQuestionnaireCommand = new RelayCommand(() => OpenFile(ExportResult?.PreInterventionPath), () => ExportResult is not null);
        OpenPostQuestionnaireCommand = new RelayCommand(() => OpenFile(ExportResult?.PostInterventionPath), () => ExportResult is not null);

        UpdateExcelRecapCommand = new RelayCommand(CreateOrUpdateExcelRecap, () => !IsUpdatingExcelRecap);
        OpenExcelRecapCommand = new RelayCommand(OpenExcelRecap, () => HasExcelRecap);
        OpenExcelOutputFolderCommand = new RelayCommand(OpenExcelOutputFolder);

        // Setiap post-test selesai, data disimpan pada satu database dan rekap gabungan diperbarui.
        CreateOrUpdateExcelRecap();
    }

    public override string Title => "Ringkasan Pengisian";
    public override string Subtitle => "Data responden telah disimpan ke database lokal. PDF per jenis kuesioner dan rekap Excel SPSS gabungan dapat dibuat atau dibuka dari halaman ini.";

    public ResearchSession Session { get; }
    public AnxietyAssessment? Pre => Session.PreAssessment;
    public AnxietyAssessment? Post => Session.PostAssessment;
    public string InterventionLabel => Session.InterventionType;
    public string PdfOutputPath => AppStoragePaths.GetPdfOutputRoot(Session.InterventionType);
    public string ModeExcelOutputPath => AppStoragePaths.GetExcelOutputRoot(Session.InterventionType);
    public string CombinedExcelPath => AppStoragePaths.CombinedExcelRecapPath;
    public string PreCategory => Pre is null ? "-" : AnxietyScoringService.GetCategoryLabel(Pre.Category);
    public string PostCategory => Post is null ? "-" : AnxietyScoringService.GetCategoryLabel(Post.Category);
    public int Change => Pre is null || Post is null ? 0 : Post.TotalScore - Pre.TotalScore;
    public string ChangeLabel => Change switch
    {
        < 0 => $"Turun {Math.Abs(Change)} poin",
        > 0 => $"Naik {Change} poin",
        _ => "Tidak berubah"
    };

    public PdfExportResult? ExportResult
    {
        get => _exportResult;
        private set
        {
            if (!SetProperty(ref _exportResult, value))
            {
                return;
            }

            OnPropertyChanged(nameof(HasExportResult));
            OpenInformedConsentCommand.RaiseCanExecuteChanged();
            OpenPreQuestionnaireCommand.RaiseCanExecuteChanged();
            OpenPostQuestionnaireCommand.RaiseCanExecuteChanged();
        }
    }

    public ExcelRecapResult? ExcelRecapResult
    {
        get => _excelRecapResult;
        private set
        {
            if (!SetProperty(ref _excelRecapResult, value))
            {
                return;
            }

            OnPropertyChanged(nameof(HasExcelRecap));
            OnPropertyChanged(nameof(ExcelRespondentCount));
            OnPropertyChanged(nameof(ModeExcelRespondentCount));
            OpenExcelRecapCommand.RaiseCanExecuteChanged();
        }
    }

    public bool HasExportResult => ExportResult is not null;
    public bool HasExcelRecap => ExcelRecapResult is not null && File.Exists(ExcelRecapResult.FilePath);
    public int ExcelRespondentCount => ExcelRecapResult?.RespondentCount ?? 0;
    public int ModeExcelRespondentCount => ExcelRecapResult?.ModeRespondentCount ?? 0;

    public string ExportStatus
    {
        get => _exportStatus;
        private set => SetProperty(ref _exportStatus, value);
    }

    public string ExcelRecapStatus
    {
        get => _excelRecapStatus;
        private set => SetProperty(ref _excelRecapStatus, value);
    }

    public bool IsExporting
    {
        get => _isExporting;
        private set
        {
            if (!SetProperty(ref _isExporting, value))
            {
                return;
            }

            GeneratePdfsCommand.RaiseCanExecuteChanged();
        }
    }

    public bool IsUpdatingExcelRecap
    {
        get => _isUpdatingExcelRecap;
        private set
        {
            if (!SetProperty(ref _isUpdatingExcelRecap, value))
            {
                return;
            }

            UpdateExcelRecapCommand.RaiseCanExecuteChanged();
        }
    }

    public RelayCommand RestartCommand { get; }
    public RelayCommand BackCommand { get; }
    public RelayCommand GeneratePdfsCommand { get; }
    public RelayCommand OpenOutputFolderCommand { get; }
    public RelayCommand OpenInformedConsentCommand { get; }
    public RelayCommand OpenPreQuestionnaireCommand { get; }
    public RelayCommand OpenPostQuestionnaireCommand { get; }
    public RelayCommand UpdateExcelRecapCommand { get; }
    public RelayCommand OpenExcelRecapCommand { get; }
    public RelayCommand OpenExcelOutputFolderCommand { get; }

    private void GeneratePdfs()
    {
        try
        {
            IsExporting = true;
            ExportStatus = $"Membuat informed consent, kuesioner pra, dan kuesioner post untuk {InterventionLabel}...";

            var result = _pdfExportService.GenerateAll(Session);
            ExportResult = result;
            ExportStatus = "Tiga PDF berhasil dibuat. Folder hasil dibuka otomatis.";
            OpenPath(result.OutputDirectory);
        }
        catch (Exception exception)
        {
            ExportStatus = $"PDF belum dapat dibuat: {exception.Message}";
        }
        finally
        {
            IsExporting = false;
        }
    }

    private void CreateOrUpdateExcelRecap()
    {
        try
        {
            IsUpdatingExcelRecap = true;
            ExcelRecapStatus = "Menyimpan data responden ke database lokal dan memperbarui rekap Excel SPSS gabungan...";

            _sessionRepository.UpsertCompletedSession(Session);
            var allSessions = _sessionRepository.GetAllCompletedSessions();
            var result = _excelRecapService.RebuildFromSessions(allSessions, Session.InterventionType);
            ExcelRecapResult = result;
            ExcelRecapStatus = $"Rekap gabungan SPSS siap. Total {result.RespondentCount} responden tersimpan, termasuk {result.ModeRespondentCount} responden {InterventionLabel}.";
        }
        catch (Exception exception)
        {
            ExcelRecapStatus = $"Rekap Excel belum dapat dibuat: {exception.Message}";
            ExcelRecapResult = null;
        }
        finally
        {
            IsUpdatingExcelRecap = false;
        }
    }

    private void OpenOutputFolder()
    {
        AppStoragePaths.EnsureDirectories();
        OpenPath(ExportResult?.OutputDirectory ?? PdfOutputPath);
    }

    private void OpenExcelRecap()
    {
        if (HasExcelRecap)
        {
            OpenPath(ExcelRecapResult!.FilePath);
        }
    }

    private void OpenExcelOutputFolder()
    {
        AppStoragePaths.EnsureDirectories();
        OpenPath(ModeExcelOutputPath);
    }

    private static void OpenFile(string? path)
    {
        if (!string.IsNullOrWhiteSpace(path) && File.Exists(path))
        {
            OpenPath(path);
        }
    }

    private static void OpenPath(string path)
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = path,
            UseShellExecute = true
        });
    }
}
