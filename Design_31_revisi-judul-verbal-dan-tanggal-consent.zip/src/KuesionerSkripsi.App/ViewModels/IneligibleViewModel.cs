using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class IneligibleViewModel : PageViewModel
{
    public IneligibleViewModel(Action restart, Action backToRespondent)
    {
        RestartCommand = new RelayCommand(restart);
        BackCommand = new RelayCommand(backToRespondent);
    }

    public override string Title => "Belum Memenuhi Persyaratan";
    public override string Subtitle => "Pengisian kuesioner tidak dapat dilanjutkan.";
    public RelayCommand RestartCommand { get; }
    public RelayCommand BackCommand { get; }
}
