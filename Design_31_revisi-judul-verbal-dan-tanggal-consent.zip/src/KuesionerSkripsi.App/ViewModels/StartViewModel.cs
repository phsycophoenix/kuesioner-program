using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class StartViewModel : PageViewModel
{
    public StartViewModel(Action start, Action showIneligible)
    {
        StartCommand = new RelayCommand(start);
        ShowIneligibleCommand = new RelayCommand(showIneligible);
    }

    public override string Title => "Mulai Pengisian";
    public override string Subtitle => "Pengisian dilakukan dengan pendampingan operator.";

    public RelayCommand StartCommand { get; }

    // Shortcut dari halaman awal untuk menampilkan halaman ucapan terima kasih.
    // Dipakai saat responden tidak memenuhi usia penelitian atau tidak bersedia.
    public RelayCommand ShowIneligibleCommand { get; }
}
