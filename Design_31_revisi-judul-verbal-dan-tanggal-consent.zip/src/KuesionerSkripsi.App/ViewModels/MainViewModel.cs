using KuesionerSkripsi.Core.Models;
using KuesionerSkripsi.Core.Services;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.ViewModels;

public sealed class MainViewModel : ObservableObject
{
    private readonly EligibilityService _eligibilityService = new();
    private readonly AnxietyScoringService _scoringService = new();
    private readonly PdfExportService _pdfExportService = new();
    private readonly SqliteSessionRepository _sessionRepository = new();
    private readonly ExcelRecapService _excelRecapService = new();
    private ResearchSession _session = new();
    private PageViewModel _currentPage = null!;
    private int _currentStep;

    public MainViewModel()
    {
        ShowStart();
    }

    public PageViewModel CurrentPage
    {
        get => _currentPage;
        private set
        {
            if (SetProperty(ref _currentPage, value))
            {
                CurrentStep = GetCurrentStep(value);
            }
        }
    }

    public int CurrentStep
    {
        get => _currentStep;
        private set
        {
            if (SetProperty(ref _currentStep, value))
            {
                OnPropertyChanged(nameof(IsStep1Reached));
                OnPropertyChanged(nameof(IsStep2Reached));
                OnPropertyChanged(nameof(IsStep3Reached));
                OnPropertyChanged(nameof(IsStep4Reached));
                OnPropertyChanged(nameof(IsStep5Reached));
                OnPropertyChanged(nameof(IsStep6Reached));
                OnPropertyChanged(nameof(IsStep7Reached));
            }
        }
    }

    public bool IsStep1Reached => CurrentStep >= 1;
    public bool IsStep2Reached => CurrentStep >= 2;
    public bool IsStep3Reached => CurrentStep >= 3;
    public bool IsStep4Reached => CurrentStep >= 4;
    public bool IsStep5Reached => CurrentStep >= 5;
    public bool IsStep6Reached => CurrentStep >= 6;
    public bool IsStep7Reached => CurrentStep >= 7;

    private static int GetCurrentStep(PageViewModel page)
    {
        return page switch
        {
            RespondentViewModel => 1,
            InformedConsentViewModel => 2,
            InterventionSelectionViewModel => 3,
            QuestionnaireViewModel questionnaire when questionnaire.IsPreIntervention => 4,
            VideoViewModel => 5,
            VerbalEducationViewModel => 5,
            QuestionnaireViewModel => 6,
            ResultViewModel => 7,
            IneligibleViewModel => 1,
            _ => 0
        };
    }

    private void ShowStart()
    {
        CurrentPage = new StartViewModel(ShowNewRespondentSession, ShowIneligible);
    }

    private void ShowNewRespondentSession()
    {
        _session = new ResearchSession();
        ShowRespondentPage();
    }

    private void ShowRespondentPage()
    {
        CurrentPage = new RespondentViewModel(_session, _eligibilityService, ShowInformedConsent, ShowIneligible, ShowStart);
    }

    private void ShowIneligible()
    {
        CurrentPage = new IneligibleViewModel(ShowStart, ShowRespondentPage);
    }

    private void ShowInformedConsent()
    {
        CurrentPage = new InformedConsentViewModel(_session, ShowRespondentPage, ShowInterventionSelection);
    }

    private void ShowInterventionSelection()
    {
        CurrentPage = new InterventionSelectionViewModel(_session, ShowInformedConsent, ShowPreQuestionnaire);
    }

    private void ShowPreQuestionnaire()
    {
        if (!InterventionTypes.IsKnown(_session.InterventionType))
        {
            ShowInterventionSelection();
            return;
        }

        CurrentPage = new QuestionnaireViewModel(_session, _scoringService, true, ShowSelectedIntervention, ShowInterventionSelection);
    }

    private void ShowSelectedIntervention()
    {
        CurrentPage = _session.InterventionType switch
        {
            InterventionTypes.VideoAnimationEducation => new VideoViewModel(ShowPostQuestionnaire, ShowPreQuestionnaire),
            InterventionTypes.VerbalEducation => new VerbalEducationViewModel(ShowPostQuestionnaire, ShowPreQuestionnaire),
            _ => new InterventionSelectionViewModel(_session, ShowInformedConsent, ShowPreQuestionnaire)
        };
    }

    private void ShowPostQuestionnaire()
    {
        CurrentPage = new QuestionnaireViewModel(_session, _scoringService, false, ShowResult, ShowSelectedIntervention);
    }

    private void ShowResult()
    {
        CurrentPage = new ResultViewModel(
            _session,
            _pdfExportService,
            _sessionRepository,
            _excelRecapService,
            ShowStart,
            ShowPostQuestionnaire);
    }
}
