namespace KuesionerSkripsi.ViewModels;

public sealed record AnswerChoice(int Score, string Label)
{
    public string Display => $"{Score} — {Label}";
}
