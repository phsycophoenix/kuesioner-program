namespace KuesionerSkripsi.Core.Models;

public sealed class AnxietyAssessment
{
    public required IReadOnlyList<int> Answers { get; init; }
    public required int TotalScore { get; init; }
    public required AnxietyCategory Category { get; init; }
    public required DateTime CompletedAt { get; init; }
}
