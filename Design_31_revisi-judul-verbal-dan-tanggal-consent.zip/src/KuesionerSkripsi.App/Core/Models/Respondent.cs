using System.Globalization;
using KuesionerSkripsi.Core.Utilities;

namespace KuesionerSkripsi.Core.Models;

public sealed class Respondent : ObservableObject
{
    private DateTime _questionnaireDate = DateTime.Today;
    private string _medicalRecordNumber = string.Empty;
    private string _fullName = string.Empty;
    private string _birthPlace = string.Empty;
    private DateTime? _birthDate;
    private string _gender = string.Empty;
    private string _education = string.Empty;
    private string _otherEducation = string.Empty;
    private string _address = string.Empty;
    private string _extractionExperience = "Tidak Pernah";
    private string _consentChoice = "Saya bersedia menjadi responden";
    private byte[]? _signaturePng;

    public DateTime QuestionnaireDate
    {
        get => _questionnaireDate;
        set
        {
            if (SetProperty(ref _questionnaireDate, value.Date))
            {
                OnPropertyChanged(nameof(AgeDisplay));
                OnPropertyChanged(nameof(AgeInYears));
            }
        }
    }

    public string MedicalRecordNumber
    {
        get => _medicalRecordNumber;
        set => SetProperty(ref _medicalRecordNumber, value ?? string.Empty);
    }

    public string FullName
    {
        get => _fullName;
        set => SetProperty(ref _fullName, CapitalizeEachWord(value));
    }

    public string BirthPlace
    {
        get => _birthPlace;
        set => SetProperty(ref _birthPlace, CapitalizeFirstLetter(value));
    }

    public DateTime? BirthDate
    {
        get => _birthDate;
        set
        {
            if (SetProperty(ref _birthDate, value))
            {
                OnPropertyChanged(nameof(AgeDisplay));
                OnPropertyChanged(nameof(AgeInYears));
            }
        }
    }

    public string Gender
    {
        get => _gender;
        set => SetProperty(ref _gender, value ?? string.Empty);
    }

    public string Education
    {
        get => _education;
        set => SetProperty(ref _education, value ?? string.Empty);
    }

    public string OtherEducation
    {
        get => _otherEducation;
        set => SetProperty(ref _otherEducation, value ?? string.Empty);
    }

    public string Address
    {
        get => _address;
        set => SetProperty(ref _address, value ?? string.Empty);
    }

    public string ExtractionExperience
    {
        get => _extractionExperience;
        set => SetProperty(ref _extractionExperience, value ?? string.Empty);
    }

    public string ConsentChoice
    {
        get => _consentChoice;
        set => SetProperty(ref _consentChoice, value ?? string.Empty);
    }

    /// <summary>
    /// PNG hasil area tanda tangan. Dipakai tahap ekspor PDF, bukan ditulis ke folder instalasi.
    /// </summary>
    public byte[]? SignaturePng
    {
        get => _signaturePng;
        private set
        {
            if (SetProperty(ref _signaturePng, value))
            {
                OnPropertyChanged(nameof(HasSignature));
            }
        }
    }

    public bool HasSignature => SignaturePng is { Length: > 0 };

    public void SetSignaturePng(byte[]? signaturePng)
    {
        SignaturePng = signaturePng is { Length: > 0 } ? signaturePng : null;
    }

    public void ClearSignature()
    {
        SignaturePng = null;
    }

    public int? AgeInYears => BirthDate is null ? null : CalculateAge(BirthDate.Value, QuestionnaireDate).Years;

    public string AgeDisplay
    {
        get
        {
            if (BirthDate is null)
            {
                return string.Empty;
            }

            var age = CalculateAge(BirthDate.Value, QuestionnaireDate);
            return $"{age.Years} Tahun, {age.Months} Bulan, {age.Days} Hari";
        }
    }

    private static string CapitalizeEachWord(string? value)
    {
        var text = value ?? string.Empty;
        if (string.IsNullOrWhiteSpace(text))
        {
            return string.Empty;
        }

        var culture = new CultureInfo("id-ID");
        return culture.TextInfo.ToTitleCase(text.ToLower(culture));
    }

    private static string CapitalizeFirstLetter(string? value)
    {
        var text = value ?? string.Empty;
        for (var index = 0; index < text.Length; index++)
        {
            if (!char.IsLetter(text[index]))
            {
                continue;
            }

            var capitalized = char.ToUpperInvariant(text[index]);
            return capitalized == text[index]
                ? text
                : text[..index] + capitalized + text[(index + 1)..];
        }

        return text;
    }

    private static (int Years, int Months, int Days) CalculateAge(DateTime birthDate, DateTime referenceDate)
    {
        var today = referenceDate.Date;
        if (birthDate.Date > today)
        {
            return (0, 0, 0);
        }

        var years = today.Year - birthDate.Year;
        var months = today.Month - birthDate.Month;
        var days = today.Day - birthDate.Day;

        if (days < 0)
        {
            months--;
            var previousMonth = today.AddMonths(-1);
            days += DateTime.DaysInMonth(previousMonth.Year, previousMonth.Month);
        }

        if (months < 0)
        {
            years--;
            months += 12;
        }

        return (years, months, days);
    }
}
