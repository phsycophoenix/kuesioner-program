namespace KuesionerSkripsi.Core.Models;

public sealed class ResearchSession
{
    /// <summary>
    /// ID unik satu kali pengisian. Digunakan untuk mencegah data ganda pada database dan Excel.
    /// </summary>
    public ResearchSession(Guid? sessionId = null, DateTime? createdAt = null)
    {
        SessionId = sessionId ?? Guid.NewGuid();
        CreatedAt = createdAt ?? DateTime.Now;
    }

    public Guid SessionId { get; }
    public DateTime CreatedAt { get; }

    /// <summary>
    /// Diisi pada tahap pilihan kuesioner setelah informed consent.
    /// </summary>
    public string InterventionType { get; set; } = string.Empty;

    public Respondent Respondent { get; } = new();
    public AnxietyAssessment? PreAssessment { get; set; }
    public AnxietyAssessment? PostAssessment { get; set; }
}
