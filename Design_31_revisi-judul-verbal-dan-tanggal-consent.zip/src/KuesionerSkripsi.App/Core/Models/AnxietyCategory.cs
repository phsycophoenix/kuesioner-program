namespace KuesionerSkripsi.Core.Models;

public enum AnxietyCategory
{
    Rendah,
    Sedang,
    Tinggi
}
