namespace KuesionerSkripsi.Core.Models;

/// <summary>
/// Nilai baku untuk membedakan jalur pengisian dalam database dan rekap SPSS gabungan.
/// </summary>
public static class InterventionTypes
{
    public const string VideoAnimationEducation = "Video Animasi Edukasi";
    public const string VerbalEducation = "Edukasi Verbal";
    public const string NotRecorded = "Tidak Tercatat";

    public static bool IsKnown(string? value)
    {
        return string.Equals(value, VideoAnimationEducation, StringComparison.Ordinal)
            || string.Equals(value, VerbalEducation, StringComparison.Ordinal);
    }
}
