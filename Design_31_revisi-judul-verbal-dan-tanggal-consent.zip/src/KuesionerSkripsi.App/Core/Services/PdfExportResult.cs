namespace KuesionerSkripsi.Core.Services;

public sealed record PdfExportResult(
    string OutputDirectory,
    string InformedConsentPath,
    string PreInterventionPath,
    string PostInterventionPath);
