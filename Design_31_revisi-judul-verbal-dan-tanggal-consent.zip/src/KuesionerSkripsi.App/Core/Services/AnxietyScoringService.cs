using KuesionerSkripsi.Core.Models;

namespace KuesionerSkripsi.Core.Services;

public sealed class AnxietyScoringService
{
    public AnxietyAssessment Calculate(IEnumerable<int> answers)
    {
        var answerList = answers.ToList();
        if (answerList.Count != 5 || answerList.Any(answer => answer is < 1 or > 5))
        {
            throw new InvalidOperationException("Lima jawaban valid dengan skor 1 sampai 5 diperlukan.");
        }

        var totalScore = answerList.Sum();
        var category = totalScore switch
        {
            <= 14 => AnxietyCategory.Rendah,
            <= 18 => AnxietyCategory.Sedang,
            _ => AnxietyCategory.Tinggi
        };

        return new AnxietyAssessment
        {
            Answers = answerList,
            TotalScore = totalScore,
            Category = category,
            CompletedAt = DateTime.Now
        };
    }

    public static string GetCategoryLabel(AnxietyCategory category) => category switch
    {
        AnxietyCategory.Rendah => "Kecemasan rendah",
        AnxietyCategory.Sedang => "Kecemasan sedang",
        AnxietyCategory.Tinggi => "Kecemasan tinggi",
        _ => throw new ArgumentOutOfRangeException(nameof(category), category, null)
    };
}
