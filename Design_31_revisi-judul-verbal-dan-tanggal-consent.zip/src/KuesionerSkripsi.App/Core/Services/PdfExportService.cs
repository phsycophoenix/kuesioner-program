using System;
using System.Globalization;
using System.IO;
using System.Linq;
using KuesionerSkripsi.Core.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace KuesionerSkripsi.Core.Services;

/// <summary>
/// Membuat tiga PDF hasil pengisian responden.
/// INFORMED CONSENT dirender sebagai dokumen teks agar tipografi dan tanda tangan rapi.
/// Kuesioner pra/post dirender ulang sebagai formulir teks agar seluruh isi memakai
/// Times New Roman 12 pt, line spacing 1,5, jawaban X tepat pada pilihan, dan
/// pengalaman pencabutan gigi dapat diberi coret pada pilihan yang tidak dipilih.
/// </summary>
public sealed class PdfExportService
{
    private const float QuestionnaireFontSize = 12f;
    private const float QuestionnaireLineHeight = 1.5f;

    public PdfExportResult GenerateAll(ResearchSession session)
    {
        ArgumentNullException.ThrowIfNull(session);
        ValidateSession(session);

        QuestPDF.Settings.License = LicenseType.Community;
        AppStoragePaths.EnsureDirectories();

        var folderName = BuildSessionFolderName(session.Respondent);
        var outputDirectory = Path.Combine(AppStoragePaths.GetPdfOutputRoot(session.InterventionType), folderName);
        Directory.CreateDirectory(outputDirectory);

        var informedConsentPath = Path.Combine(outputDirectory, "INFORMED CONSENT.pdf");
        var prePath = Path.Combine(outputDirectory, GetQuestionnaireFileName(session.InterventionType, true));
        var postPath = Path.Combine(outputDirectory, GetQuestionnaireFileName(session.InterventionType, false));

        GenerateInformedConsent(informedConsentPath, session.Respondent, GetStudyTitle(session.InterventionType));
        GenerateQuestionnaire(prePath, session.Respondent, session.PreAssessment!, true, session.InterventionType);
        GenerateQuestionnaire(postPath, session.Respondent, session.PostAssessment!, false, session.InterventionType);

        return new PdfExportResult(outputDirectory, informedConsentPath, prePath, postPath);
    }

    private static void GenerateInformedConsent(string outputPath, Respondent respondent, string studyTitle)
    {
        var respondentSignature = respondent.SignaturePng;
        var researcherSignature = GetResearcherSignature();
        var date = respondent.QuestionnaireDate.ToString("dd MMMM yyyy", new CultureInfo("id-ID"));

        var document = Document.Create(document =>
        {
            document.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.MarginLeft(60);
                page.MarginRight(60);
                page.MarginTop(54);
                page.MarginBottom(54);
                page.DefaultTextStyle(style => style
                    .FontFamily("Times New Roman")
                    .FontSize(12)
                    .LineHeight(1.5f));

                page.Content().Column(column =>
                {
                    const float oneParagraphSpacing = 18f;
                    const float twoParagraphSpacing = 36f;

                    column.Item().AlignCenter().Text("(INFORMED CONSENT)").Bold().Italic();
                    column.Item().PaddingTop(twoParagraphSpacing).Text("Saya yang bertanda tangan dibawah ini :");

                    column.Item().PaddingTop(oneParagraphSpacing).Column(identity =>
                    {
                        identity.Item().Element(container => AddConsentIdentityRow(container, "Nama", respondent.FullName));
                        identity.Item().Element(container => AddConsentIdentityRow(container, "Umur", respondent.AgeDisplay));
                        identity.Item().Element(container => AddConsentIdentityRow(container, "Alamat", respondent.Address));
                    });

                    column.Item().PaddingTop(twoParagraphSpacing).Text(text =>
                    {
                        text.Span("Setelah saya mendapatkan keterangan secukupnya serta mengetahui tentang tujuan dari penelitian ini, maka saya menyatakan bersedia menjadi responden dari penelitian yang berjudul “");
                        text.Span(studyTitle).Bold();
                        text.Span("”.");
                    });

                    column.Item().PaddingTop(18).Text("Persetujuan ini saya tandatangani tanpa paksaan dari siapa pun.");

                    column.Item().PaddingTop(28).Row(row =>
                    {
                        row.RelativeItem().PaddingRight(24).Column(left =>
                        {
                            left.Item().PaddingTop(34).AlignCenter().Text("Peneliti");
                            left.Item().PaddingTop(6).Height(104).AlignCenter().Image(researcherSignature).FitArea();
                            left.Item().AlignCenter().Text("Tanti Widiyastuti");
                        });

                        row.RelativeItem().PaddingLeft(24).Column(right =>
                        {
                            right.Item().AlignCenter().Text($"Purbalingga, {date}");
                            right.Item().PaddingTop(8).AlignCenter().Text("Responden");
                            right.Item().PaddingTop(6).Height(104).AlignCenter().Image(respondentSignature!).FitArea();
                            right.Item().AlignCenter().Text(respondent.FullName);
                        });
                    });
                });
            });
        });

        document.GeneratePdf(outputPath);
    }

    private static string GetStudyTitle(string interventionType)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => "Efektivitas Video Animasi Edukasi Pra Tindakan terhadap Kecemasan Pasien Ekstraksi Gigi di Poli Bedah Mulut RSUD Panti Nugroho Kabupaten Purbalingga",
            InterventionTypes.VerbalEducation => "Efektivitas Video Animasi Edukasi Pra Tindakan terhadap Kecemasan Pasien Ekstraksi Gigi di Poli Bedah Mulut RSUD Panti Nugroho Kabupaten Purbalingga",
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    private static string GetQuestionnaireFileName(string interventionType, bool isPreIntervention)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => isPreIntervention
                ? "KUESIONER PRA INTERVENSI VIDEO ANIMASI SEBAGAI MEDIA EDUKASI PADA TINGKAT KECEMASAN PASIEN EKSTRKSI GIGI.pdf"
                : "KUESIONER POST INTERVENSI VIDEO ANIMASI SEBAGAI MEDIA EDUKASI PADA TINGKAT KECEMASAN PASIEN EKSTRKSI GIGI.pdf",
            InterventionTypes.VerbalEducation => isPreIntervention
                ? "KUESIONER PRA EDUKASI VERBAL TERHADAP KECEMASAN PASIEN EKSTRAKSI GIGI.pdf"
                : "KUESIONER POST EDUKASI VERBAL TERHADAP KECEMASAN PASIEN EKSTRAKSI GIGI.pdf",
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    private static string GetQuestionnaireTitle(string interventionType, bool isPreIntervention)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => isPreIntervention
                ? "KUESIONER PRA INTERVENSI VIDEO ANIMASI SEBAGAI MEDIA EDUKASI PADA TINGKAT KECEMASAN PASIEN EKSTRKSI GIGI"
                : "KUESIONER POST INTERVENSI VIDEO ANIMASI SEBAGAI MEDIA EDUKASI PADA TINGKAT KECEMASAN PASIEN EKSTRKSI GIGI",
            InterventionTypes.VerbalEducation => isPreIntervention
                ? "KUESIONER PRA INTERVENSI EDUKASI VERBAL TERHADAP KECEMASAN PASIEN EKSTRAKSI GIGI"
                : "KUESIONER POST INTERVENSI EDUKASI VERBAL TERHADAP KECEMASAN PASIEN EKSTRAKSI GIGI",
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    private static void AddConsentIdentityRow(IContainer container, string label, string? value)
    {
        container.Row(row =>
        {
            row.ConstantItem(56).Text(label);
            row.ConstantItem(15).Text(":");
            row.RelativeItem().Text(value ?? string.Empty);
        });
    }

    private static void GenerateQuestionnaire(
        string outputPath,
        Respondent respondent,
        AnxietyAssessment assessment,
        bool isPreIntervention,
        string interventionType)
    {
        var title = GetQuestionnaireTitle(interventionType, isPreIntervention);

        var education = respondent.Education == "Lainnya" && !string.IsNullOrWhiteSpace(respondent.OtherEducation)
            ? respondent.OtherEducation
            : respondent.Education;

        var document = Document.Create(document =>
        {
            document.Page(page =>
            {
                ConfigureQuestionnairePage(page);
                page.Content().Column(column =>
                {
                    AddQuestionnaireHeading(column, title);
                    AddIdentitySection(column, respondent, education);
                    AddInstructionSection(column);
                    column.Item().PaddingTop(12).Text("Kuesioner Tingkat Kecemasan MDAS-DEP").Bold();
                    column.Item().PaddingTop(6).Element(container => AddQuestion(container, 1, QuestionTexts[0], assessment.Answers[0]));
                    column.Item().PaddingTop(16).Element(container => AddQuestion(container, 2, QuestionTexts[1], assessment.Answers[1]));
                });
            });

            document.Page(page =>
            {
                ConfigureQuestionnairePage(page);
                page.Content().Column(column =>
                {
                    column.Item().Element(container => AddQuestion(container, 3, QuestionTexts[2], assessment.Answers[2]));
                    column.Item().PaddingTop(16).Element(container => AddQuestion(container, 4, QuestionTexts[3], assessment.Answers[3]));
                    column.Item().PaddingTop(16).Element(container => AddQuestion(container, 5, QuestionTexts[4], assessment.Answers[4]));
                    column.Item().PaddingTop(24).Element(AddScoringSection);
                    column.Item().PaddingTop(20).Element(container => AddResultSection(container, assessment));
                });
            });
        });

        document.GeneratePdf(outputPath);
    }

    private static void ConfigureQuestionnairePage(PageDescriptor page)
    {
        page.Size(PageSizes.A4);
        page.MarginLeft(48);
        page.MarginRight(48);
        page.MarginTop(42);
        page.MarginBottom(42);
        page.DefaultTextStyle(style => style
            .FontFamily("Times New Roman")
            .FontSize(QuestionnaireFontSize)
            .LineHeight(QuestionnaireLineHeight));
    }

    private static void AddQuestionnaireHeading(ColumnDescriptor column, string title)
    {
        column.Item().AlignCenter().Text(title).Bold();
    }

    private static void AddIdentitySection(ColumnDescriptor column, Respondent respondent, string education)
    {
        column.Item().PaddingTop(18).Text("Data Identitas Responden").Bold();
        column.Item().PaddingTop(6).Column(identity =>
        {
            identity.Item().Element(container => AddQuestionnaireIdentityRow(container, "Tanggal Pengisian", respondent.QuestionnaireDate.ToString("dddd, dd MMMM yyyy", new CultureInfo("id-ID"))));
            identity.Item().Element(container => AddQuestionnaireIdentityRow(container, "Nama/Inisial", respondent.FullName));
            identity.Item().Element(container => AddQuestionnaireIdentityRow(container, "Umur", respondent.AgeDisplay));
            identity.Item().Element(container => AddQuestionnaireIdentityRow(container, "Jenis Kelamin", respondent.Gender));
            identity.Item().Element(container => AddQuestionnaireIdentityRow(container, "Pendidikan", education));
            identity.Item().PaddingTop(2).Element(container => AddExperienceLine(container, respondent.ExtractionExperience));
        });
    }

    private static void AddQuestionnaireIdentityRow(IContainer container, string label, string? value)
    {
        container.Row(row =>
        {
            row.ConstantItem(192).Text(label);
            row.ConstantItem(14).Text(":");
            row.RelativeItem().Text(value ?? string.Empty);
        });
    }

    private static void AddExperienceLine(IContainer container, string experience)
    {
        container.Text(text =>
        {
            text.Span("Pengalaman pencabutan gigi sebelumnya : ");
            if (string.Equals(experience, "Pernah", StringComparison.OrdinalIgnoreCase))
            {
                text.Span("Pernah");
                text.Span(" / ");
                text.Span("Tidak Pernah").Strikethrough();
            }
            else
            {
                text.Span("Pernah").Strikethrough();
                text.Span(" / ");
                text.Span("Tidak Pernah");
            }
        });
    }

    private static void AddInstructionSection(ColumnDescriptor column)
    {
        column.Item().PaddingTop(18).Text("Petunjuk Pengisian").Bold();
        column.Item().Text("Jawablah pertanyaan di bawah ini dengan memberi tanda silang (X) pada salah satu jawaban yang paling sesuai dengan perasaan Anda.");
        column.Item().PaddingTop(4).Text("Keterangan jawaban :");
        column.Item().PaddingTop(2).Row(row =>
        {
            row.RelativeItem().Column(left =>
            {
                left.Item().Text("a. Tidak cemas.");
                left.Item().Text("b. Sedikit cemas.");
            });
            row.RelativeItem().Column(middle =>
            {
                middle.Item().Text("c. Cukup cemas.");
                middle.Item().Text("d. Cemas.");
            });
            row.RelativeItem().Column(right =>
            {
                right.Item().Text("e. Sangat cemas.");
            });
        });
    }

    private static void AddQuestion(IContainer container, int number, string questionText, int selectedScore)
    {
        container.Column(question =>
        {
            question.Item().Row(row =>
            {
                row.ConstantItem(24).Text($"{number}.");
                row.RelativeItem().Text(questionText);
            });

            question.Item().PaddingTop(4).PaddingLeft(24).Row(row =>
            {
                row.RelativeItem().Column(left =>
                {
                    left.Item().Element(cell => AddAnswerOption(cell, "a", "Tidak cemas.", selectedScore == 1));
                    left.Item().Element(cell => AddAnswerOption(cell, "b", "Sedikit cemas.", selectedScore == 2));
                });
                row.RelativeItem().Column(middle =>
                {
                    middle.Item().Element(cell => AddAnswerOption(cell, "c", "Cukup cemas.", selectedScore == 3));
                    middle.Item().Element(cell => AddAnswerOption(cell, "d", "Cemas.", selectedScore == 4));
                });
                row.RelativeItem().Column(right =>
                {
                    right.Item().Element(cell => AddAnswerOption(cell, "e", "Sangat cemas.", selectedScore == 5));
                });
            });
        });
    }

    private static void AddAnswerOption(IContainer container, string letter, string label, bool isSelected)
    {
        container.Row(row =>
        {
            // Tanda X ditempatkan bertumpuk tepat pada huruf pilihan a/b/c/d/e,
            // bukan di samping jawaban, agar menyerupai pengisian manual pada formulir.
            row.ConstantItem(22).Element(marker => AddAnswerMarker(marker, letter, isSelected));
            row.RelativeItem().Text(label);
        });
    }

    private static void AddAnswerMarker(IContainer container, string letter, bool isSelected)
    {
        container.Layers(layers =>
        {
            layers.PrimaryLayer().AlignLeft().Text($"{letter}.");
            if (isSelected)
            {
                layers.Layer().AlignLeft().Text("X");
            }
        });
    }

    private static void AddScoringSection(IContainer container)
    {
        container.Column(column =>
        {
            column.Item().Text("Skoring").Bold();
            column.Item().PaddingTop(2).Row(row =>
            {
                row.RelativeItem().Text("a = 1.");
                row.RelativeItem().Text("b = 2.");
                row.RelativeItem().Text("c = 3.");
                row.RelativeItem().Text("d = 4.");
                row.RelativeItem().Text("e = 5.");
            });
            column.Item().Text("Total skor minimum = 5.     Total skor maksimum = 25");
            column.Item().PaddingTop(12).Text("Kategori Tingkat Kecemasan").Bold();
            column.Item().PaddingTop(2).Row(row =>
            {
                row.RelativeItem().Text("5–14 = Kecemasan rendah.");
                row.RelativeItem().Text("15–18 = Kecemasan sedang.");
                row.RelativeItem().Text("19–25 = Kecemasan tinggi.");
            });
        });
    }

    private static void AddResultSection(IContainer container, AnxietyAssessment assessment)
    {
        var category = AnxietyScoringService.GetCategoryLabel(assessment.Category);

        container.Border(1).PaddingVertical(16).PaddingHorizontal(12).Column(result =>
        {
            result.Item().AlignCenter().Text("Skor dan Kategori Tingkat Kecemasan Responden").Bold();
            result.Item().PaddingTop(14).AlignCenter().Text("Skor :");
            result.Item().PaddingTop(4).AlignCenter().Text(assessment.TotalScore.ToString(CultureInfo.InvariantCulture));
            result.Item().PaddingTop(14).AlignCenter().Text("Kategori Tingkat Kecemasan :");
            result.Item().PaddingTop(4).AlignCenter().Text(category);
        });
    }

    private static byte[] GetResearcherSignature()
    {
        var assembly = typeof(PdfExportService).Assembly;
        const string suffix = ".Resources.Images.TandaTanganPenelitiPdf.png";
        var resourceName = assembly.GetManifestResourceNames()
            .SingleOrDefault(name => name.EndsWith(suffix, StringComparison.Ordinal));

        if (resourceName is null)
        {
            throw new InvalidOperationException("Tanda tangan peneliti tidak ditemukan dalam aplikasi.");
        }

        using var stream = assembly.GetManifestResourceStream(resourceName)
            ?? throw new InvalidOperationException("Tanda tangan peneliti tidak dapat dibaca.");
        using var buffer = new MemoryStream();
        stream.CopyTo(buffer);
        return buffer.ToArray();
    }

    private static string BuildSessionFolderName(Respondent respondent)
    {
        var medicalRecord = SanitizeFileNamePart(string.IsNullOrWhiteSpace(respondent.MedicalRecordNumber)
            ? "TANPA_RM"
            : respondent.MedicalRecordNumber);
        var name = SanitizeFileNamePart(string.IsNullOrWhiteSpace(respondent.FullName)
            ? "RESPONDEN"
            : respondent.FullName);
        return $"{medicalRecord}_{name}_{DateTime.Now:yyyyMMdd_HHmmss}";
    }

    private static string SanitizeFileNamePart(string value)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var cleaned = new string(value.Select(character => invalid.Contains(character) ? '_' : character).ToArray());
        cleaned = cleaned.Replace(' ', '_');
        return string.IsNullOrWhiteSpace(cleaned) ? "RESPONDEN" : cleaned;
    }

    private static void ValidateSession(ResearchSession session)
    {
        if (session.PreAssessment is null || session.PostAssessment is null)
        {
            throw new InvalidOperationException("Data pre-test dan post-test belum lengkap.");
        }

        if (!session.Respondent.HasSignature)
        {
            throw new InvalidOperationException("Tanda tangan responden belum tersedia untuk PDF informed consent.");
        }

        if (!InterventionTypes.IsKnown(session.InterventionType))
        {
            throw new InvalidOperationException("Jenis kuesioner belum dipilih.");
        }
    }

    private static readonly string[] QuestionTexts =
    [
        "Jika Anda diberitahu bahwa salah satu gigi Anda harus dicabut, bagaimana perasaan Anda?",
        "Jika besok Anda akan menjalani tindakan ekstraksi gigi, bagaimana perasaan Anda?",
        "Jika Anda sedang menunggu di ruang tunggu untuk tindakan ekstraksi gigi, bagaimana perasaan Anda?",
        "Jika Anda akan mendapatkan suntikan anestesi lokal pada gusi, bagaimana perasaan Anda?",
        "Jika gigi Anda akan dicabut melalui prosedur ekstraksi gigi, bagaimana perasaan Anda?"
    ];
}
