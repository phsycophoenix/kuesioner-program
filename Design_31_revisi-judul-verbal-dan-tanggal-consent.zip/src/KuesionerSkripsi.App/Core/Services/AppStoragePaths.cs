using System;
using System.IO;
using KuesionerSkripsi.Core.Models;

namespace KuesionerSkripsi.Core.Services;

/// <summary>
/// Semua data penelitian memakai satu database dan satu rekap SPSS gabungan.
/// PDF serta rekap Excel per jalur tetap disimpan pada folder masing-masing.
/// </summary>
public static class AppStoragePaths
{
    public const string Root = @"D:\Kuesioner";

    public static string DatabaseRoot => Path.Combine(Root, "Database");
    public static string DatabasePath => Path.Combine(DatabaseRoot, "Kuesioner.db");
    public static string CombinedExcelArchiveRoot => Path.Combine(DatabaseRoot, "Arsip");
    public static string CombinedExcelRecapPath => Path.Combine(DatabaseRoot, "REKAP_KUESIONER_GABUNGAN_SPSS.xlsx");

    public static string VideoRoot => Path.Combine(Root, "Video Animasi Edukasi");
    public static string VideoPdfOutputRoot => Path.Combine(VideoRoot, "Hasil PDF");
    public static string VideoExcelOutputRoot => Path.Combine(VideoRoot, "Hasil Exel");
    public static string VideoExcelArchiveRoot => Path.Combine(VideoExcelOutputRoot, "Arsip");
    public static string VideoExcelRecapPath => Path.Combine(VideoExcelOutputRoot, "REKAP_KUESIONER_VIDEO_ANIMASI_EDUKASI.xlsx");

    public static string VerbalRoot => Path.Combine(Root, "Edukasi Verbal");
    public static string VerbalPdfOutputRoot => Path.Combine(VerbalRoot, "Hasil PDF");
    public static string VerbalExcelOutputRoot => Path.Combine(VerbalRoot, "Hasil Exel");
    public static string VerbalExcelArchiveRoot => Path.Combine(VerbalExcelOutputRoot, "Arsip");
    public static string VerbalExcelRecapPath => Path.Combine(VerbalExcelOutputRoot, "REKAP_KUESIONER_EDUKASI_VERBAL.xlsx");

    public static string GetPdfOutputRoot(string interventionType)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => VideoPdfOutputRoot,
            InterventionTypes.VerbalEducation => VerbalPdfOutputRoot,
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    public static string GetExcelOutputRoot(string interventionType)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => VideoExcelOutputRoot,
            InterventionTypes.VerbalEducation => VerbalExcelOutputRoot,
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    public static string GetExcelArchiveRoot(string interventionType)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => VideoExcelArchiveRoot,
            InterventionTypes.VerbalEducation => VerbalExcelArchiveRoot,
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    public static string GetExcelRecapPath(string interventionType)
    {
        return interventionType switch
        {
            InterventionTypes.VideoAnimationEducation => VideoExcelRecapPath,
            InterventionTypes.VerbalEducation => VerbalExcelRecapPath,
            _ => throw new InvalidOperationException("Jenis kuesioner belum dipilih.")
        };
    }

    public static void EnsureDirectories()
    {
        try
        {
            Directory.CreateDirectory(Root);
            Directory.CreateDirectory(DatabaseRoot);
            Directory.CreateDirectory(CombinedExcelArchiveRoot);

            Directory.CreateDirectory(VideoPdfOutputRoot);
            Directory.CreateDirectory(VideoExcelOutputRoot);
            Directory.CreateDirectory(VideoExcelArchiveRoot);

            Directory.CreateDirectory(VerbalPdfOutputRoot);
            Directory.CreateDirectory(VerbalExcelOutputRoot);
            Directory.CreateDirectory(VerbalExcelArchiveRoot);
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or NotSupportedException)
        {
            throw new InvalidOperationException(
                "Folder D:\\Kuesioner tidak dapat dibuat atau diakses. Pastikan drive D: tersedia dan dapat ditulis.",
                exception);
        }
    }
}
