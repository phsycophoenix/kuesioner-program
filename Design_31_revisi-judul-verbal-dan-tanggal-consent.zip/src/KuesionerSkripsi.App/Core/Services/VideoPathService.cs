using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace KuesionerSkripsi.Core.Services;

public static class VideoPathService
{
    public const string BundledVideoRelativePath = "Video\\Video.mp4";

    public static bool TryResolveBundledVideo(out string videoPath)
    {
        foreach (var candidate in GetCandidatePaths())
        {
            if (File.Exists(candidate) && new FileInfo(candidate).Length > 0)
            {
                videoPath = candidate;
                return true;
            }
        }

        videoPath = string.Empty;
        return false;
    }

    public static IReadOnlyList<string> GetCandidatePaths()
    {
        var applicationFolder = AppContext.BaseDirectory;
        var installedFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
            "Kuesioner");

        return new[]
        {
            Path.Combine(applicationFolder, "Video", "Video.mp4"),
            Path.Combine(installedFolder, "Video", "Video.mp4")
        }
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToArray();
    }
}
