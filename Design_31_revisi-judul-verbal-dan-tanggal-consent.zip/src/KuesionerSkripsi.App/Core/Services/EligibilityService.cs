using KuesionerSkripsi.Core.Models;

namespace KuesionerSkripsi.Core.Services;

public sealed class EligibilityService
{
    public const int MinimumAge = 17;
    public const int MaximumAge = 59;
    public const string ConsentAccepted = "Saya bersedia menjadi responden";
    public const string ConsentDeclined = "Saya tidak bersedia menjadi responden";

    public bool IsEligible(Respondent respondent)
    {
        return respondent.AgeInYears is >= MinimumAge and <= MaximumAge
               && respondent.ConsentChoice == ConsentAccepted;
    }

    public string GetIneligibilityReason(Respondent respondent)
    {
        if (respondent.AgeInYears is null)
        {
            return "Tanggal lahir belum dapat digunakan untuk memeriksa usia.";
        }

        if (respondent.AgeInYears < MinimumAge || respondent.AgeInYears > MaximumAge)
        {
            return $"Usia responden harus berada pada rentang {MinimumAge}–{MaximumAge} tahun.";
        }

        if (respondent.ConsentChoice == ConsentDeclined)
        {
            return "Responden memilih tidak bersedia mengikuti penelitian.";
        }

        return "Responden belum memenuhi kriteria awal penelitian.";
    }
}
