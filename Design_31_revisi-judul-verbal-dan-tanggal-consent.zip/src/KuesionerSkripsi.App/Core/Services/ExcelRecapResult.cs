namespace KuesionerSkripsi.Core.Services;

public sealed record ExcelRecapResult(
    string FilePath,
    string ArchivePath,
    int RespondentCount,
    string ModeFilePath,
    string ModeArchivePath,
    int ModeRespondentCount);
