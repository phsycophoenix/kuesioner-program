using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ClosedXML.Excel;
using KuesionerSkripsi.Core.Models;

namespace KuesionerSkripsi.Core.Services;

/// <summary>
/// Membuat satu rekap SPSS gabungan pada folder Database serta rekap per jenis kuesioner.
/// Semua file selalu dibuat ulang dari isi database lokal agar tetap konsisten.
/// </summary>
public sealed class ExcelRecapService
{
    private const string DataSheetName = "DATA_SPSS";
    private const string CodebookSheetName = "KODEBOOK_SPSS";

    private static readonly string[] Headers =
    [
        "ID_Sesi",
        "Jenis_Kuesioner",
        "Tanggal_Pengisian",
        "No_Rekam_Medis",
        "Nama_Responden",
        "Tempat_Lahir",
        "Tanggal_Lahir",
        "Umur_Tahun",
        "Umur_Tampil",
        "Jenis_Kelamin_Kode",
        "Jenis_Kelamin",
        "Pendidikan",
        "Pendidikan_Lainnya",
        "Alamat",
        "Pengalaman_Pencabutan_Kode",
        "Pengalaman_Pencabutan",
        "Pre_Q1",
        "Pre_Q2",
        "Pre_Q3",
        "Pre_Q4",
        "Pre_Q5",
        "Pre_Skor",
        "Pre_Kategori_Kode",
        "Pre_Kategori",
        "Post_Q1",
        "Post_Q2",
        "Post_Q3",
        "Post_Q4",
        "Post_Q5",
        "Post_Skor",
        "Post_Kategori_Kode",
        "Post_Kategori",
        "Delta_Post_Min_Pre",
        "Waktu_Selesai"
    ];

    public ExcelRecapResult RebuildFromSessions(IReadOnlyList<ResearchSession> sessions, string currentInterventionType)
    {
        ArgumentNullException.ThrowIfNull(sessions);
        if (!InterventionTypes.IsKnown(currentInterventionType))
        {
            throw new InvalidOperationException("Jenis kuesioner belum dipilih.");
        }

        AppStoragePaths.EnsureDirectories();

        var allSessions = sessions.ToList();
        var videoSessions = allSessions
            .Where(session => session.InterventionType == InterventionTypes.VideoAnimationEducation)
            .ToList();
        var verbalSessions = allSessions
            .Where(session => session.InterventionType == InterventionTypes.VerbalEducation)
            .ToList();
        var currentModeSessions = currentInterventionType == InterventionTypes.VideoAnimationEducation
            ? videoSessions
            : verbalSessions;

        var combinedArchivePath = SaveWorkbook(
            allSessions,
            AppStoragePaths.CombinedExcelRecapPath,
            AppStoragePaths.CombinedExcelArchiveRoot,
            "REKAP_KUESIONER_GABUNGAN_SPSS");

        var videoArchivePath = SaveWorkbook(
            videoSessions,
            AppStoragePaths.VideoExcelRecapPath,
            AppStoragePaths.VideoExcelArchiveRoot,
            "REKAP_KUESIONER_VIDEO_ANIMASI_EDUKASI");

        var verbalArchivePath = SaveWorkbook(
            verbalSessions,
            AppStoragePaths.VerbalExcelRecapPath,
            AppStoragePaths.VerbalExcelArchiveRoot,
            "REKAP_KUESIONER_EDUKASI_VERBAL");

        var modeFilePath = AppStoragePaths.GetExcelRecapPath(currentInterventionType);
        var modeArchivePath = currentInterventionType == InterventionTypes.VideoAnimationEducation
            ? videoArchivePath
            : verbalArchivePath;

        return new ExcelRecapResult(
            AppStoragePaths.CombinedExcelRecapPath,
            combinedArchivePath,
            allSessions.Count,
            modeFilePath,
            modeArchivePath,
            currentModeSessions.Count);
    }

    private static string SaveWorkbook(
        IReadOnlyList<ResearchSession> sessions,
        string outputPath,
        string archiveRoot,
        string archiveNamePrefix)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        Directory.CreateDirectory(archiveRoot);

        using var workbook = new XLWorkbook();
        var dataSheet = workbook.Worksheets.Add(DataSheetName);
        var codebookSheet = workbook.Worksheets.Add(CodebookSheetName);

        WriteDataSheet(dataSheet, sessions);
        WriteCodebookSheet(codebookSheet);

        var temporaryPath = Path.Combine(
            Path.GetDirectoryName(outputPath)!,
            $"~REKAP_{Guid.NewGuid():N}.xlsx");

        workbook.SaveAs(temporaryPath);
        File.Copy(temporaryPath, outputPath, true);

        var archivePath = Path.Combine(
            archiveRoot,
            $"{archiveNamePrefix}_{DateTime.Now:yyyyMMdd_HHmmss_fff}.xlsx");
        File.Copy(temporaryPath, archivePath, false);
        File.Delete(temporaryPath);

        return archivePath;
    }

    private static void WriteDataSheet(IXLWorksheet worksheet, IReadOnlyList<ResearchSession> sessions)
    {
        for (var index = 0; index < Headers.Length; index++)
        {
            worksheet.Cell(1, index + 1).Value = Headers[index];
        }

        for (var index = 0; index < sessions.Count; index++)
        {
            WriteDataRow(worksheet, index + 2, sessions[index]);
        }

        FormatDataSheet(worksheet, Math.Max(1, sessions.Count + 1));
    }

    private static void WriteDataRow(IXLWorksheet worksheet, int row, ResearchSession session)
    {
        var respondent = session.Respondent;
        var pre = session.PreAssessment ?? throw new InvalidOperationException("Data pre-test belum tersedia.");
        var post = session.PostAssessment ?? throw new InvalidOperationException("Data post-test belum tersedia.");

        var values = new object?[]
        {
            session.SessionId.ToString("N"),
            string.IsNullOrWhiteSpace(session.InterventionType) ? InterventionTypes.NotRecorded : session.InterventionType,
            respondent.QuestionnaireDate,
            respondent.MedicalRecordNumber,
            respondent.FullName,
            respondent.BirthPlace,
            respondent.BirthDate,
            respondent.AgeInYears,
            respondent.AgeDisplay,
            GetGenderCode(respondent.Gender),
            respondent.Gender,
            respondent.Education,
            respondent.OtherEducation,
            respondent.Address,
            GetExtractionExperienceCode(respondent.ExtractionExperience),
            respondent.ExtractionExperience,
            pre.Answers[0], pre.Answers[1], pre.Answers[2], pre.Answers[3], pre.Answers[4],
            pre.TotalScore,
            GetCategoryCode(pre.Category),
            AnxietyScoringService.GetCategoryLabel(pre.Category),
            post.Answers[0], post.Answers[1], post.Answers[2], post.Answers[3], post.Answers[4],
            post.TotalScore,
            GetCategoryCode(post.Category),
            AnxietyScoringService.GetCategoryLabel(post.Category),
            post.TotalScore - pre.TotalScore,
            post.CompletedAt
        };

        for (var column = 0; column < values.Length; column++)
        {
            SetCellValue(worksheet.Cell(row, column + 1), values[column]);
        }

        worksheet.Cell(row, 3).Style.DateFormat.Format = "[$-421]dddd, dd mmmm yyyy";
        worksheet.Cell(row, 7).Style.DateFormat.Format = "[$-421]dddd, dd mmmm yyyy";
        worksheet.Cell(row, 34).Style.DateFormat.Format = "[$-421]dddd, dd mmmm yyyy HH:mm";
        worksheet.Row(row).Style.Alignment.Vertical = XLAlignmentVerticalValues.Top;
        worksheet.Cell(row, 5).Style.Alignment.WrapText = true;
        worksheet.Cell(row, 14).Style.Alignment.WrapText = true;
    }

    private static void SetCellValue(IXLCell cell, object? value)
    {
        switch (value)
        {
            case null:
                cell.Clear(XLClearOptions.Contents);
                break;
            case string text:
                cell.Value = text;
                break;
            case int number:
                cell.Value = number;
                break;
            case DateTime date:
                cell.Value = date;
                break;
            default:
                cell.Value = value.ToString() ?? string.Empty;
                break;
        }
    }

    private static void FormatDataSheet(IXLWorksheet worksheet, int lastRow)
    {
        var headerRange = worksheet.Range(1, 1, 1, Headers.Length);
        headerRange.Style.Font.Bold = true;
        headerRange.Style.Font.FontColor = XLColor.White;
        headerRange.Style.Fill.BackgroundColor = XLColor.FromHtml("#163B5B");
        headerRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
        headerRange.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
        headerRange.Style.Alignment.WrapText = true;
        worksheet.Row(1).Height = 32;
        worksheet.SheetView.FreezeRows(1);
        worksheet.Range(1, 1, lastRow, Headers.Length).SetAutoFilter();

        var widths = new[]
        {
            34d, 26d, 27d, 17d, 25d, 20d, 27d, 11d, 24d, 17d, 16d, 22d, 22d, 46d,
            24d, 26d, 9d, 9d, 9d, 9d, 9d, 11d, 21d, 19d, 9d, 9d, 9d, 9d, 9d, 12d,
            22d, 20d, 18d, 31d
        };

        for (var column = 0; column < widths.Length; column++)
        {
            worksheet.Column(column + 1).Width = widths[column];
        }

        worksheet.Column(1).Style.Font.FontColor = XLColor.FromHtml("#64748B");
        worksheet.Column(5).Style.Alignment.WrapText = true;
        worksheet.Column(14).Style.Alignment.WrapText = true;
    }

    private static void WriteCodebookSheet(IXLWorksheet worksheet)
    {
        var rows = new List<(string Variable, string Label, string Type, string Values)>
        {
            ("ID_Sesi", "ID unik satu kali pengisian", "String", "Digunakan untuk mencegah data ganda saat rekap diperbarui"),
            ("Jenis_Kuesioner", "Jenis edukasi yang dipilih setelah informed consent", "String", "Video Animasi Edukasi; Edukasi Verbal; Tidak Tercatat hanya untuk data lama"),
            ("Tanggal_Pengisian", "Tanggal responden mengisi kuesioner", "Date", "Format Selasa, 22 Juni 2026"),
            ("No_Rekam_Medis", "Nomor rekam medis", "String", "Diisi oleh petugas"),
            ("Umur_Tahun", "Usia responden dalam tahun", "Numeric", "17-59 untuk responden yang memenuhi syarat"),
            ("Jenis_Kelamin_Kode", "Kode jenis kelamin", "Numeric", "1=Laki-laki; 2=Perempuan"),
            ("Pengalaman_Pencabutan_Kode", "Pengalaman pencabutan gigi", "Numeric", "1=Pernah; 2=Tidak Pernah"),
            ("Pre_Q1 sampai Pre_Q5", "Jawaban pre-test MDAS-DEP", "Numeric", "1=Tidak cemas; 2=Sedikit cemas; 3=Cukup cemas; 4=Cemas; 5=Sangat cemas"),
            ("Pre_Skor", "Jumlah skor pre-test", "Numeric", "Rentang 5-25"),
            ("Pre_Kategori_Kode", "Kategori kecemasan pre-test", "Numeric", "1=Rendah; 2=Sedang; 3=Tinggi"),
            ("Post_Q1 sampai Post_Q5", "Jawaban post-test MDAS-DEP", "Numeric", "1=Tidak cemas; 2=Sedikit cemas; 3=Cukup cemas; 4=Cemas; 5=Sangat cemas"),
            ("Post_Skor", "Jumlah skor post-test", "Numeric", "Rentang 5-25"),
            ("Post_Kategori_Kode", "Kategori kecemasan post-test", "Numeric", "1=Rendah; 2=Sedang; 3=Tinggi"),
            ("Delta_Post_Min_Pre", "Perubahan skor kecemasan", "Numeric", "Post_Skor - Pre_Skor; nilai negatif menunjukkan penurunan"),
            ("Waktu_Selesai", "Waktu post-test selesai", "DateTime", "Format Selasa, 22 Juni 2026 HH:mm")
        };

        worksheet.Cell(1, 1).Value = "Nama_Variabel";
        worksheet.Cell(1, 2).Value = "Label_Variabel";
        worksheet.Cell(1, 3).Value = "Tipe_Data";
        worksheet.Cell(1, 4).Value = "Nilai_dan_Keterangan";

        for (var row = 0; row < rows.Count; row++)
        {
            var item = rows[row];
            worksheet.Cell(row + 2, 1).Value = item.Variable;
            worksheet.Cell(row + 2, 2).Value = item.Label;
            worksheet.Cell(row + 2, 3).Value = item.Type;
            worksheet.Cell(row + 2, 4).Value = item.Values;
        }

        var headerRange = worksheet.Range(1, 1, 1, 4);
        headerRange.Style.Font.Bold = true;
        headerRange.Style.Font.FontColor = XLColor.White;
        headerRange.Style.Fill.BackgroundColor = XLColor.FromHtml("#163B5B");
        headerRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
        headerRange.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
        headerRange.Style.Alignment.WrapText = true;

        worksheet.Column(1).Width = 29;
        worksheet.Column(2).Width = 44;
        worksheet.Column(3).Width = 16;
        worksheet.Column(4).Width = 78;
        worksheet.Column(2).Style.Alignment.WrapText = true;
        worksheet.Column(4).Style.Alignment.WrapText = true;
        worksheet.SheetView.FreezeRows(1);
        worksheet.Range(1, 1, Math.Max(1, rows.Count + 1), 4).SetAutoFilter();
    }

    private static int? GetGenderCode(string? gender)
    {
        return gender switch
        {
            "Laki-laki" => 1,
            "Perempuan" => 2,
            _ => null
        };
    }

    private static int? GetExtractionExperienceCode(string? experience)
    {
        return experience switch
        {
            "Pernah" => 1,
            "Tidak Pernah" => 2,
            _ => null
        };
    }

    private static int GetCategoryCode(AnxietyCategory category)
    {
        return category switch
        {
            AnxietyCategory.Rendah => 1,
            AnxietyCategory.Sedang => 2,
            AnxietyCategory.Tinggi => 3,
            _ => 0
        };
    }
}
