namespace KuesionerSkripsi.Views;

public partial class IneligiblePage : System.Windows.Controls.UserControl
{
    public IneligiblePage()
    {
        InitializeComponent();
    }
}
