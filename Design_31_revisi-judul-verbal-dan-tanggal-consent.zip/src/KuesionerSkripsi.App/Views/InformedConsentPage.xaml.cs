namespace KuesionerSkripsi.Views;

public partial class InformedConsentPage : System.Windows.Controls.UserControl
{
    public InformedConsentPage()
    {
        InitializeComponent();
    }
}
