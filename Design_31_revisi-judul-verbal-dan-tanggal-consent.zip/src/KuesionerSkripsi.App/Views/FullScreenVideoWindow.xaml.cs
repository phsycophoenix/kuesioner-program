using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using KuesionerSkripsi.ViewModels;

namespace KuesionerSkripsi.Views;

public partial class FullScreenVideoWindow : Window
{
    private readonly VideoViewModel _viewModel;
    private readonly DispatcherTimer _startRetryTimer;
    private bool _mediaOpened;
    private bool _completionHandled;

    public FullScreenVideoWindow(VideoViewModel viewModel)
    {
        _viewModel = viewModel;
        DataContext = viewModel;
        InitializeComponent();

        _startRetryTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(600)
        };
        _startRetryTimer.Tick += StartRetryTimer_Tick;
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        StartPlayback();
    }

    private void Window_ContentRendered(object? sender, EventArgs e)
    {
        // WPF MediaElement can require the final layout pass before it starts rendering.
        StartPlayback();
        _startRetryTimer.Start();
    }

    private void StartRetryTimer_Tick(object? sender, EventArgs e)
    {
        if (_mediaOpened || _completionHandled)
        {
            _startRetryTimer.Stop();
            return;
        }

        StartPlayback();
    }

    private void StartPlayback()
    {
        if (_completionHandled || _viewModel.VideoUri is null)
        {
            return;
        }

        // Assigning Source directly prevents a delayed binding refresh from leaving a blank screen.
        if (VideoPlayer.Source is null || VideoPlayer.Source != _viewModel.VideoUri)
        {
            VideoPlayer.Source = _viewModel.VideoUri;
        }

        VideoPlayer.Play();
    }

    private void VideoPlayer_MediaOpened(object sender, RoutedEventArgs e)
    {
        _mediaOpened = true;
        _startRetryTimer.Stop();
        _viewModel.NotifyMediaOpened();
        VideoPlayer.Play();
    }

    private void VideoPlayer_MediaEnded(object sender, RoutedEventArgs e)
    {
        CompleteAndOpenPostTest();
    }

    private void VideoPlayer_MediaFailed(object sender, ExceptionRoutedEventArgs e)
    {
        if (_completionHandled)
        {
            return;
        }

        _startRetryTimer.Stop();
        VideoPlayer.Stop();
        _viewModel.NotifyMediaFailed(e.ErrorException?.Message);
        Close();
    }

    private void CompleteAndOpenPostTest()
    {
        if (_completionHandled)
        {
            return;
        }

        _completionHandled = true;
        _startRetryTimer.Stop();
        VideoPlayer.Stop();

        // Close fullscreen first, then move directly to Post-test without another manual click.
        Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            Close();
            _viewModel.NotifyMediaEndedAndContinue();
        }));
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape && !_completionHandled)
        {
            // Closing before the end never grants access to Post-test.
            _startRetryTimer.Stop();
            VideoPlayer.Stop();
            Close();
        }
    }
}
