using System.Windows.Controls;

namespace KuesionerSkripsi.Views;

public partial class VerbalEducationPage : UserControl
{
    public VerbalEducationPage()
    {
        InitializeComponent();
    }
}
