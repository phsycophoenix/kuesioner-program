using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using KuesionerSkripsi.ViewModels;

namespace KuesionerSkripsi.Views;

public partial class RespondentPage : UserControl
{
    public RespondentPage()
    {
        InitializeComponent();
    }

    private void SignatureCanvas_StrokeCollected(object sender, InkCanvasStrokeCollectedEventArgs e)
    {
        SaveSignatureSnapshot();
    }

    private void ClearSignature_Click(object sender, RoutedEventArgs e)
    {
        SignatureCanvas.Strokes.Clear();
        if (DataContext is RespondentViewModel viewModel)
        {
            viewModel.Respondent.ClearSignature();
        }
    }

    private void SaveSignatureSnapshot()
    {
        if (DataContext is not RespondentViewModel viewModel || SignatureCanvas.Strokes.Count == 0)
        {
            return;
        }

        var width = Math.Max(1, (int)Math.Ceiling(SignatureCanvas.ActualWidth));
        var height = Math.Max(1, (int)Math.Ceiling(SignatureCanvas.ActualHeight));
        var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
        bitmap.Render(SignatureCanvas);

        // Simpan hanya area tinta tanda tangan. Hal ini membuat tanda tangan berada tepat
        // di tengah di atas nama responden saat dokumen PDF dirender.
        var strokeBounds = SignatureCanvas.Strokes.GetBounds();
        const double padding = 12;
        var left = Math.Max(0, (int)Math.Floor(strokeBounds.Left - padding));
        var top = Math.Max(0, (int)Math.Floor(strokeBounds.Top - padding));
        var right = Math.Min(width, (int)Math.Ceiling(strokeBounds.Right + padding));
        var bottom = Math.Min(height, (int)Math.Ceiling(strokeBounds.Bottom + padding));
        var cropWidth = Math.Max(1, right - left);
        var cropHeight = Math.Max(1, bottom - top);

        var cropped = new CroppedBitmap(bitmap, new Int32Rect(left, top, cropWidth, cropHeight));
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(cropped));
        using var stream = new MemoryStream();
        encoder.Save(stream);
        viewModel.Respondent.SetSignaturePng(stream.ToArray());
    }
}
