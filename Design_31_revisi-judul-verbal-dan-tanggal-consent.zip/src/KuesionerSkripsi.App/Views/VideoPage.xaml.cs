using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Microsoft.Win32;
using KuesionerSkripsi.ViewModels;

namespace KuesionerSkripsi.Views;

public partial class VideoPage : UserControl
{
    private bool _hasAutoOpened;
    private FullScreenVideoWindow? _fullScreenWindow;

    public VideoPage()
    {
        InitializeComponent();
    }

    private void VideoPage_Loaded(object sender, RoutedEventArgs e)
    {
        if (_hasAutoOpened || DataContext is not VideoViewModel viewModel || !viewModel.HasVideoSource)
        {
            return;
        }

        _hasAutoOpened = true;
        Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(OpenFullScreenVideo));
    }

    private void ChooseReplacementVideo_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Pilih Video Edukasi",
            Filter = "Video MP4 (*.mp4)|*.mp4|Semua file video (*.mp4;*.wmv;*.avi;*.mov)|*.mp4;*.wmv;*.avi;*.mov|Semua file (*.*)|*.*",
            CheckFileExists = true,
            Multiselect = false
        };

        if (dialog.ShowDialog() == true && DataContext is VideoViewModel viewModel)
        {
            viewModel.SetReplacementVideo(dialog.FileName);
            OpenFullScreenVideo();
        }
    }

    private void ReplayVideo_Click(object sender, RoutedEventArgs e)
    {
        if (DataContext is not VideoViewModel viewModel || !viewModel.HasVideoSource)
        {
            return;
        }

        viewModel.NotifyReplayStarted();
        OpenFullScreenVideo();
    }

    private void OpenFullScreenVideo()
    {
        if (DataContext is not VideoViewModel viewModel || !viewModel.HasVideoSource)
        {
            return;
        }

        if (_fullScreenWindow is { IsVisible: true })
        {
            return;
        }

        _fullScreenWindow = new FullScreenVideoWindow(viewModel)
        {
            Owner = Window.GetWindow(this)
        };
        _fullScreenWindow.ShowDialog();
    }
}
