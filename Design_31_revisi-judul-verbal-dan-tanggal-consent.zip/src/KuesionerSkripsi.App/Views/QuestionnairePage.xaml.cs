using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace KuesionerSkripsi.Views;

public partial class QuestionnairePage : UserControl
{
    public QuestionnairePage()
    {
        InitializeComponent();
    }

    private void QuestionnairePage_Loaded(object sender, RoutedEventArgs e)
    {
        // Halaman Pre-test dan Post-test selalu dibuka dari bagian paling atas.
        Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
        {
            DependencyObject current = this;
            while (current is not null)
            {
                if (current is ScrollViewer scrollViewer)
                {
                    scrollViewer.ScrollToTop();
                    break;
                }

                current = VisualTreeHelper.GetParent(current);
            }
        }));
    }
}
