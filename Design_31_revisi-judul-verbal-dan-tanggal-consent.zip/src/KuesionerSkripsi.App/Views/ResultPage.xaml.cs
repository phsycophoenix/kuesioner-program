namespace KuesionerSkripsi.Views;

public partial class ResultPage : System.Windows.Controls.UserControl
{
    public ResultPage()
    {
        InitializeComponent();
    }
}
