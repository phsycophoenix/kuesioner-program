namespace KuesionerSkripsi.Views;

public partial class StartPage : System.Windows.Controls.UserControl
{
    public StartPage()
    {
        InitializeComponent();
    }
}
