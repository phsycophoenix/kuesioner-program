using System.Windows.Controls;

namespace KuesionerSkripsi.Views;

public partial class InterventionSelectionPage : UserControl
{
    public InterventionSelectionPage()
    {
        InitializeComponent();
    }
}
