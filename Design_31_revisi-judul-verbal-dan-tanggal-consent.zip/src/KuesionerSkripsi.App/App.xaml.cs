namespace KuesionerSkripsi;

public partial class App : System.Windows.Application
{
}
