# Kuesioner Skripsi - Design_30

Aplikasi Windows WPF untuk dua jalur penelitian kecemasan pasien ekstraksi gigi:

1. Video Animasi Edukasi
2. Edukasi Verbal

## Alur

Data Responden → Informed Consent → Pilih Jenis Kuesioner → Pre-test → Intervensi sesuai pilihan → Post-test → Hasil.

Semua halaman setelah halaman awal memiliki tombol kembali ke tahap sebelumnya. Jawaban kuesioner yang sudah disimpan pada sesi berjalan akan dipulihkan ketika pengguna kembali ke halaman pre-test atau post-test.

## Format tanggal

Tampilan tanggal menggunakan format Bahasa Indonesia dengan nama hari dan nama bulan lengkap, misalnya `Selasa, 22 Juni 2026`. Format ini diterapkan pada form data responden, informed consent, PDF, dan tampilan tanggal pada rekap Excel. Nilai tanggal di Excel tetap disimpan sebagai tanggal agar siap diolah di SPSS.

## Penyimpanan

- Database gabungan: `D:\Kuesioner\Database\Kuesioner.db`
- Rekap SPSS gabungan: `D:\Kuesioner\Database\REKAP_KUESIONER_GABUNGAN_SPSS.xlsx`
- Output Video Animasi Edukasi:
  - PDF: `D:\Kuesioner\Video Animasi Edukasi\Hasil PDF`
  - Excel: `D:\Kuesioner\Video Animasi Edukasi\Hasil Exel`
- Output Edukasi Verbal:
  - PDF: `D:\Kuesioner\Edukasi Verbal\Hasil PDF`
  - Excel: `D:\Kuesioner\Edukasi Verbal\Hasil Exel`

## Build dan publish lokal

1. Buka `KuesionerSkripsi.sln` di Visual Studio.
2. Jalankan **Build > Rebuild Solution**.
3. Publish menggunakan `Release`, `net8.0-windows`, `win-x64`, dan `Self-contained`.
4. Pastikan folder publish berisi `Video\Video.mp4`.
5. Compile `installer\KuesionerSetup.iss` melalui Inno Setup.
